# Allergen Sweep

Photograph a food label. Get every allergen in it — including the ones hiding under
names like *casein* and *semolina* — plus the cross-contact risks and a set of
substitutions that make the recipe safe.

No framework, no build step, no `npm install`. It's HTML, CSS and three JavaScript
files, plus one serverless function. You can open `index.html` in a browser right now
and everything except photo scanning will work.

---

## How it's put together

| File | What it does |
|---|---|
| `index.html` | The whole page. Markup only. |
| `styles.css` | All styling. Light and dark themes are defined as CSS variables at the top — change six values and the whole app reskins. |
| `engine.js` | **The product.** The allergen rulebook and the substitution table. ~1,100 ingredient terms, no dependencies, runs entirely in the browser. |
| `app.js` | The UI: capture, parsing, rendering, local storage. |
| `api/scan.js` | The only server code. Sends a photo to Claude, gets back the text printed on the label. |
| `test/engine.test.js` | 36 assertions covering the traps. Run it after any edit to `engine.js`. |
| `sw.js` | Service worker. Caches the app so text scanning works with no signal. |

### The one design decision that matters

**The AI transcribes. The rulebook decides.**

`api/scan.js` asks Claude one question: *what does this label say?* It is explicitly
told never to infer an ingredient it cannot read. Everything after that — what counts
as an allergen, what's a hidden derivative, what's cross-contact, what to substitute —
is a fixed table in `engine.js` that runs on the user's device.

This matters for three reasons. Every user gets an identical answer for an identical
label. You can audit and correct any rule. And no model is ever the thing deciding
whether food is safe for someone to eat.

Keep that split if you change anything.

---

## Deploying it

### 1. Get an API key

Sign up at <https://console.anthropic.com>, create a key, add a small amount of credit.
Cost is covered below — it's very little.

### 2. Push to GitHub

```bash
cd allergen-sweep
git init
git add .
git commit -m "Allergen Sweep"
gh repo create allergen-sweep --private --source=. --push
```

No `gh` CLI? Create an empty repo on github.com and follow the push instructions it gives you.

### 3. Deploy on Vercel

1. Go to <https://vercel.com>, sign in with GitHub, **Add New → Project**, pick the repo.
2. Framework preset: **Other**. Leave build and output settings empty.
3. Before deploying, open **Environment Variables** and add:

   | Name | Value |
   |---|---|
   | `ANTHROPIC_API_KEY` | your key from step 1 |
   | `SCAN_MODEL` | `claude-haiku-4-5-20251001` *(optional — this is the default)* |

4. Deploy. You get a live URL in about a minute.

Every `git push` after this redeploys automatically.

**Check it worked:** open the site. Under the Scan button it should say *"Photo reading
ready."* If it says *"not switched on yet"*, the environment variable didn't save —
add it under Settings → Environment Variables and redeploy.

### Running it locally

```bash
npm i -g vercel
vercel dev          # serves the site and the function together on :3000
```

For the front end alone, any static server works: `npx serve .` — photo scanning will
report as unavailable, everything else runs.

---

## What it costs you

Haiku 4.5 is $1 per million input tokens, $5 per million output.

A label photo, after the app shrinks it to 1600px, is roughly 1,500 tokens. Add the
prompt and the reply and a scan lands near **$0.004** — about **$4 per thousand scans**.

Vercel's free tier covers the hosting and the function calls at small scale.

So: a thousand people scanning one label each costs you about four dollars. Ten thousand
scans is forty. Worth knowing before you post it anywhere that might send real traffic.

---

## Editing the rulebook

This is the part you'll actually touch. Everything lives in `engine.js`:

**Add an ingredient to an allergen** — find the `add()` call and put the term in the list:

```js
add('milk', 'hidden', ['casein', 'caseinate', 'whey', 'your new term']);
```

Levels are `contains` (it IS the allergen), `hidden` (a derivative people miss), and
`possible` (usually carries it, not guaranteed).

**Stop a false positive** — add the phrase to `decoy()`. Longest match wins, so
`'almond milk'` in the decoy list stops `'milk'` from matching inside it:

```js
decoy(['almond milk', 'cocoa butter', 'buckwheat']);
```

**Add a substitution:**

```js
sub(['butter'], ['milk'], [
  { use: 'Vegan butter block', ratio: '1:1', note: 'Use a block, not a tub.' },
]);
```

**Then always:**

```bash
npm test
```

36 assertions guard the traps — almond milk isn't dairy, soy sauce is also wheat,
eggplant isn't egg, buckwheat isn't wheat. If you break one, you'll know immediately.
Add a `check()` line for every rule you add.

---

## Before you send this to strangers

**Rate limiting is weak.** `api/scan.js` throttles per IP in memory, which resets
whenever a serverless instance recycles. It slows casual abuse, not a determined one.
If the site gets real traffic, add [Vercel KV](https://vercel.com/docs/storage/vercel-kv)
or Upstash Redis and move the counter there. Someone hammering your endpoint spends
your API credit.

**Put up a disclaimer people actually see.** The footer text is a start, but if
strangers are going to eat based on this, add a terms page saying plainly: this is an
aid, not a clearance; it reads what is printed and cannot see what isn't; for a severe
allergy the manufacturer is the source of truth. That's honest, and it's the sort of
thing you want written down beforehand rather than afterwards.

**Saved recipes live in the browser only.** Clearing site data clears them, and they
don't follow the user to another device. Real accounts mean a database and a login —
worth building once people ask for it, not before.

---

## Where to take it next, roughly in order

1. **Watch whether anyone scans twice.** One scan is curiosity. Two is a product.
2. **Barcode lookup** — Open Food Facts has a free API and millions of products.
   Scanning a barcode beats photographing a label when the product is in the database.
3. **Shareable results** — a link to a scan is how this spreads. Needs a small database.
4. **Charge kitchens, not eaters.** The allergen statement and the supplier
   question list are what a business will pay for. The safety report should stay free —
   that's both the right call and the reason people come back.
