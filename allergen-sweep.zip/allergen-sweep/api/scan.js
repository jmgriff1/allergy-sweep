/**
 * POST /api/scan
 *
 * Takes one to four base64 photos of a food label and returns the text that is
 * printed on it, as structured JSON. This is the ONLY part of the app that
 * leaves the user's device, and it does exactly one job: transcription.
 *
 * Every allergen decision is made afterwards, in the browser, by engine.js.
 * That split is deliberate — the rules are auditable and identical for every
 * user, and a model is never the thing deciding whether food is safe.
 *
 * GET /api/scan  ->  { ready: boolean }  (is the key configured?)
 */

const MODEL = process.env.SCAN_MODEL || 'claude-haiku-4-5-20251001';
const MAX_IMAGES = 4;
const MAX_BYTES_PER_IMAGE = 3_500_000;   // base64 chars, ~2.6MB of binary
const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

/* Best-effort throttle. Serverless instances come and go, so this slows down
   casual abuse but is not a real limiter — see the README for the durable fix. */
const RATE = new Map();
const WINDOW_MS = 60_000;
const MAX_PER_WINDOW = 12;

function rateLimited(ip) {
  const now = Date.now();
  const hits = (RATE.get(ip) || []).filter(t => now - t < WINDOW_MS);
  hits.push(now);
  RATE.set(ip, hits);
  if (RATE.size > 5000) RATE.clear();
  return hits.length > MAX_PER_WINDOW;
}

const PROMPT = `You are transcribing a photograph of food packaging, a recipe card, a menu, or a screenshot of one.

Transcribe only what is actually written or clearly shown. Never infer, complete, or correct an ingredient that is not legible — an invented ingredient on an allergy report is dangerous. If you cannot read something, say so in "unreadable" rather than guessing.

Reply with only this JSON, no other text:
{"title": string, "ingredients": [string], "prep": [string], "claims": [string], "legibility": "clear"|"partial"|"poor", "unreadable": [string]}

- title: what the item is called, or a short description of the dish
- ingredients: one entry per ingredient, exactly as written, keeping sub-ingredients inside their parentheses
- prep: cooking, handling or facility statements ("made on equipment that also processes tree nuts", "deep fried")
- claims: free-from, vegan, kosher, halal or dietary claims printed on the item
- legibility: how well you could read it overall
- unreadable: short descriptions of any portion you could not make out

Example: {"title":"Granola Bar","ingredients":["rolled oats","honey","soy lecithin"],"prep":["Made on shared equipment"],"claims":["gluten-free"],"legibility":"clear","unreadable":[]}`;

/** Pull a JSON object out of a reply that may be fenced or have stray prose. */
function extractJson(text) {
  const tryParse = (s) => { try { return JSON.parse(s); } catch (e) { return null; } };
  let v = tryParse(text.trim());
  if (v) return v;
  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fence && (v = tryParse(fence[1].trim()))) return v;
  const start = text.indexOf('{'), end = text.lastIndexOf('}');
  if (start !== -1 && end > start && (v = tryParse(text.slice(start, end + 1)))) return v;
  return null;
}

export default async function handler(req, res) {
  const key = process.env.ANTHROPIC_API_KEY;

  if (req.method === 'GET') return res.status(200).json({ ready: Boolean(key) });
  if (req.method !== 'POST') return res.status(405).json({ error: 'method_not_allowed' });
  if (!key) return res.status(503).json({ error: 'no_api_key' });

  const ip = (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'unknown';
  if (rateLimited(ip)) return res.status(429).json({ error: 'rate_limited' });

  const images = Array.isArray(req.body?.images) ? req.body.images.slice(0, MAX_IMAGES) : [];
  if (!images.length) return res.status(400).json({ error: 'no_images' });

  for (const im of images) {
    if (!im || typeof im.data !== 'string') return res.status(400).json({ error: 'bad_image' });
    if (!ALLOWED_TYPES.includes(im.mediaType)) return res.status(400).json({ error: 'bad_image' });
    if (im.data.length > MAX_BYTES_PER_IMAGE) return res.status(413).json({ error: 'too_large' });
  }

  try {
    const upstream = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': key,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 1500,
        messages: [{
          role: 'user',
          content: [
            ...images.map(im => ({
              type: 'image',
              source: { type: 'base64', media_type: im.mediaType, data: im.data },
            })),
            { type: 'text', text: PROMPT },
          ],
        }],
      }),
    });

    if (!upstream.ok) {
      const detail = await upstream.text();
      console.error('anthropic error', upstream.status, detail.slice(0, 500));
      if (upstream.status === 429) return res.status(429).json({ error: 'rate_limited' });
      return res.status(502).json({ error: 'upstream' });
    }

    const payload = await upstream.json();
    const text = (payload.content || []).filter(b => b.type === 'text').map(b => b.text).join('\n');
    const data = extractJson(text);
    if (!data || !Array.isArray(data.ingredients)) return res.status(422).json({ error: 'unreadable' });

    // Never trust shape from a model — normalise before it reaches the engine.
    const strings = (v) => (Array.isArray(v) ? v : []).map(String).map(s => s.trim()).filter(Boolean).slice(0, 120);
    return res.status(200).json({
      title: String(data.title || 'Scanned label').slice(0, 120),
      ingredients: strings(data.ingredients),
      prep: strings(data.prep),
      claims: strings(data.claims),
      legibility: ['clear', 'partial', 'poor'].includes(data.legibility) ? data.legibility : 'partial',
      unreadable: strings(data.unreadable).slice(0, 6),
      usage: payload.usage || null,
    });
  } catch (e) {
    console.error('scan failed', e);
    return res.status(502).json({ error: 'upstream' });
  }
}

export const config = { api: { bodyParser: { sizeLimit: '12mb' } } };
