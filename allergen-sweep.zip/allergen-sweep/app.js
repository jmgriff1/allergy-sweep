import { analyze, substitute, ALLERGENS, LEVELS } from './engine.js';

/* ============================================================
   APP
   ============================================================ */

const FEEDBACK_URL = "mailto:you@example.com?subject=Allergen%20Sweep";  // <- your email

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const LS = {
  get(k, d) { try { const v = localStorage.getItem('as.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem('as.' + k, JSON.stringify(v)); } catch (e) {} },
};

const REGULATED = Object.keys(ALLERGENS).filter(k => ALLERGENS[k].group === 'regulated');
const DIETARY = Object.keys(ALLERGENS).filter(k => ALLERGENS[k].group === 'dietary');
const LEVEL_WORD = { contains: 'Contains', hidden: 'Hidden source', possible: 'Possible' };

const state = {
  profile: new Set(LS.get('profile', [])),
  pro: true,
  library: LS.get('library', []),
  swapMode: LS.get('swapMode', 'mine'),
  images: [],
  result: null,
  meta: null,
  ctl: null,
};

/* ---------- sample scan so the page opens on a real report ---------- */
const SAMPLE = {
  title: 'Almond croissant, bakery case',
  ingredients: [
    'Enriched wheat flour (niacin, reduced iron, thiamine)',
    'Butter (cream, salt)',
    'Almond paste (almonds, sugar)',
    'Water, sugar, yeast, sea salt',
    'Whey powder',
    'Natural flavors',
    'Sliced almonds',
  ],
  prep: [
    'Egg wash applied before bake.',
    'Baked in a bakery case shared with sesame semolina loaves and hazelnut danish.',
  ],
  claims: [],
};

/* ============================================================
   THEME
   ============================================================ */
$('themeBtn').onclick = () => {
  const cur = document.documentElement.getAttribute('data-theme');
  const dark = cur ? cur === 'dark'
    : window.matchMedia('(prefers-color-scheme: dark)').matches;
  document.documentElement.setAttribute('data-theme', dark ? 'light' : 'dark');
  LS.set('theme', dark ? 'light' : 'dark');
};
(function () { const t = LS.get('theme', null); if (t) document.documentElement.setAttribute('data-theme', t); })();

/* ============================================================
   PROFILE
   ============================================================ */
function renderChips() {
  $('profileChips').innerHTML = REGULATED.map(k =>
    `<button class="chip" type="button" data-a="${k}" aria-pressed="${state.profile.has(k)}">${esc(ALLERGENS[k].label)}</button>`
  ).join('');
  $('profileChips').querySelectorAll('.chip').forEach(b => {
    b.onclick = () => {
      const k = b.dataset.a;
      state.profile.has(k) ? state.profile.delete(k) : state.profile.add(k);
      LS.set('profile', [...state.profile]);
      renderChips();
      if (state.result) renderReport();
    };
  });
}

/* ============================================================
   REPORT
   ============================================================ */
function levelOf(a) { return state.result.found[a]?.level; }

function crossAllergens() {
  const m = new Map();
  for (const c of state.result.cross) for (const a of c.allergens) {
    if (!m.has(a)) m.set(a, []);
    m.get(a).push(c);
  }
  return m;
}

function markup(line) {
  const spans = new Map();
  for (const h of line.hits) {
    const k = h.start + ':' + h.end;
    if (!spans.has(k)) spans.set(k, { s: h.start, e: h.end, lv: h.l, as: [] });
    const sp = spans.get(k);
    sp.as.push(ALLERGENS[h.a].label);
    if (LEVELS[h.l] > LEVELS[sp.lv]) sp.lv = h.l;
  }
  const list = [...spans.values()].sort((a, b) => a.s - b.s);
  let out = '', at = 0;
  for (const sp of list) {
    if (sp.s < at) continue;
    out += esc(line.text.slice(at, sp.s));
    out += `<mark class="${sp.lv}" title="${esc(sp.as.join(', '))}">${esc(line.text.slice(sp.s, sp.e))}</mark>`;
    at = sp.e;
  }
  return out + esc(line.text.slice(at));
}

function confidence() {
  const r = state.result, m = state.meta || {};
  let score = 100;
  const gaps = [];
  if (m.legibility === 'partial') { score -= 22; gaps.push(['Photo', 'Parts of the label were hard to read, so the ingredient list may be incomplete.']); }
  if (m.legibility === 'poor') { score -= 45; gaps.push(['Photo', 'The photo was largely unreadable. Re-shoot it straight on, in even light.']); }
  for (const u of (m.unreadable || []).slice(0, 3)) gaps.push(['Unread', u]);
  score -= Math.min(36, r.vague.length * 9);
  for (const v of r.vague) gaps.push([v.t, v.why]);
  const poss = Object.values(r.found).filter(f => f.level === 'possible').length;
  if (poss) { score -= Math.min(12, poss * 3); }
  if (r.cross.length) score -= Math.min(10, r.cross.length * 3);
  return { score: Math.max(8, Math.round(score)), gaps };
}

function verdict() {
  const r = state.result;
  const cross = crossAllergens();
  const mine = [...state.profile];
  if (mine.length) {
    const hard = mine.filter(a => LEVELS[levelOf(a)] >= 2);
    const soft = mine.filter(a => levelOf(a) === 'possible');
    const traced = mine.filter(a => !levelOf(a) && cross.has(a));
    if (hard.length) return {
      cls: 'hit',
      h: `Do not eat — ${list(hard)} ${hard.length > 1 ? 'are' : 'is'} in this`,
      p: `Declared or derivative-level match against your profile.`,
    };
    if (soft.length) return {
      cls: 'watch', h: `${cap(list(soft))} may be in this`,
      p: 'Matched on an ingredient that carries it in most formulations, not on a named declaration. Confirm before eating.',
    };
    if (traced.length) return {
      cls: 'watch', h: `No ${list(traced)} declared, but the process risks it`,
      p: 'Nothing in the ingredients, yet the way this is made makes cross-contact likely. See below.',
    };
    return {
      cls: 'ok', h: `Nothing from your profile found`,
      p: `Checked ${mine.length} allergen${mine.length > 1 ? 's' : ''} against ${r.counts.ingredients} ingredient lines. Read the gaps panel before you trust it.`,
    };
  }
  const hard = REGULATED.filter(a => LEVELS[levelOf(a)] >= 2);
  if (!hard.length) return { cls: 'ok', h: 'No regulated allergen declared', p: 'Nothing in the Big 9 or the EU 14 appears in this ingredient list.' };
  return {
    cls: 'watch',
    h: `${hard.length} regulated allergen${hard.length > 1 ? 's' : ''} declared: ${list(hard)}`,
    p: 'Pick your own allergens and this verdict speaks to you instead of the general list.',
  };
}
const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
const list = ks => ks.map(k => ALLERGENS[k].label.toLowerCase()).join(', ').replace(/, ([^,]*)$/, ' and $1');

function declaration() {
  const r = state.result, cross = crossAllergens();
  const contains = REGULATED.filter(a => LEVELS[levelOf(a)] >= 2)
    .map(a => {
      const ev = r.found[a].evidence.filter(e => LEVELS[e.level] >= 2).slice(0, 2).map(e => e.term.toLowerCase());
      return ALLERGENS[a].label + (ev.length ? ` (${ev.join(', ')})` : '');
    });
  const may = REGULATED.filter(a => LEVELS[levelOf(a)] < 2 && (levelOf(a) === 'possible' || cross.has(a)))
    .map(a => ALLERGENS[a].label);
  return { contains, may };
}

/* ============================================================
   SUBSTITUTIONS
   ============================================================ */
function swapScope() {
  const hard = REGULATED.filter(a => LEVELS[levelOf(a)] >= 2);
  if (state.swapMode === 'mine' && state.profile.size) {
    return new Set(hard.filter(a => state.profile.has(a)));
  }
  return new Set(hard);
}

function renderSwaps() {
  const scope = swapScope();
  if (!scope.size) {
    return `<div class="panel"><div class="ph"><span class="eyebrow">Make it safe</span></div>
      <div class="pb"><p class="note">${state.swapMode === 'mine' && state.profile.size
        ? 'Nothing in this recipe hits your profile, so there is nothing to swap.'
        : 'No declared allergen to swap out.'}</p></div></div>`;
  }
  const plan = substitute(state.result, scope);
  const names = ks => ks.map(k => ALLERGENS[k].label.toLowerCase()).join(', ').replace(/, ([^,]*)$/, ' and $1');
  const mine = state.profile.size > 0;

  const seg = `<span class="seg">
    <button type="button" data-mode="mine" aria-pressed="${state.swapMode === 'mine'}" ${mine ? '' : 'disabled title="Pick your allergens first"'}>My allergens</button>
    <button type="button" data-mode="all" aria-pressed="${state.swapMode !== 'mine'}">Everything found</button>
  </span>`;

  let banner;
  if (plan.cleared.length && !plan.stillThere.length) {
    banner = `<div class="banner"><b>${plan.rows.length} swap${plan.rows.length > 1 ? 's' : ''} clears ${esc(names(plan.cleared))}.</b> Texture and bake time will shift — the notes say how.</div>`;
  } else if (plan.stillThere.length) {
    banner = `<div class="banner"><b>${plan.rows.length} swap${plan.rows.length > 1 ? 's' : ''} below.</b> ${esc(cap(names(plan.stillThere)))} cannot be swapped out of this recipe — see what is left.</div>`;
  } else {
    banner = `<div class="banner">Nothing here has a home substitution. Read what is left below.</div>`;
  }

  const rows = plan.rows.map(row => {
    const [first, ...alts] = row.swaps;
    return `<div class="swap">
      <div class="head">
        <span class="from">${esc(row.term)}</span>
        <span class="arrow">→</span>
        <span class="to">${esc(first.use)}</span>
        <span class="fixes">clears ${esc(names(row.allergens))}</span>
      </div>
      <div><span class="ratio">${esc(first.ratio)}</span></div>
      ${first.note ? `<p class="sn">${esc(first.note)}</p>` : ''}
      ${alts.map(s => `<p class="alt"><b>${esc(s.use)}</b> — ${esc(s.ratio)}${s.note ? '. ' + esc(s.note) : ''}</p>`).join('')}
      ${row.caveat ? `<p class="caveat">${esc(row.caveat)}</p>` : ''}
    </div>`;
  }).join('');

  const leftovers = [
    ...plan.blocked.map(b => [b.term, b.why]),
    ...plan.unfixable.map(u => [u.label, u.why]),
  ];

  return `<div class="panel"><div class="ph"><span class="eyebrow">Make it safe</span>${seg}</div>
    <div class="pb">${banner}</div>
    ${rows ? `<div class="swaps">${rows}</div>` : ''}
    ${leftovers.length ? `<div class="pb bt">
      <span class="eyebrow">What swapping won't fix</span>
      <div class="gaps">${leftovers.map(([t, w]) => `<div class="gap"><code>${esc(t)}</code><span>${esc(w)}</span></div>`).join('')}</div>
    </div>` : ''}
    <div class="pb bt">
      <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn" id="copySwapBtn" type="button">Copy the rebuilt list</button></div>
      <p class="note">A substitution is not a clearance. Check the label on whatever you buy to replace it — sunflower butter and gluten-free flour both get made on shared lines.</p>
      <div id="swapMsg" class="note" hidden></div>
    </div>
  </div>`;
}

function swapText() {
  const scope = swapScope();
  const plan = substitute(state.result, scope);
  const L = [state.result.title.toUpperCase() + ' — rebuilt without ' + [...scope].map(a => ALLERGENS[a].label.toLowerCase()).join(', '), ''];
  for (const row of plan.rows) {
    L.push('- ' + row.term + '  ->  ' + row.swaps[0].use + '  (' + row.swaps[0].ratio + ')');
    if (row.swaps[0].note) L.push('    ' + row.swaps[0].note);
  }
  if (plan.blocked.length || plan.unfixable.length) {
    L.push('', 'STILL TO SORT OUT');
    for (const b of plan.blocked) L.push('- ' + b.term + ': ' + b.why);
    for (const u of plan.unfixable) L.push('- ' + u.label + ': ' + u.why);
  }
  L.push('', 'Check the label on every replacement product before you use it.');
  return L.join('\n');
}

function renderReport() {
  const r = state.result, meta = state.meta || {}, cross = crossAllergens();
  const v = verdict(), d = declaration(), conf = confidence();
  const mine = state.profile;
  const out = [];

  out.push(`<div class="verdict ${v.cls}">
    <div class="vtext"><h2>${esc(v.h)}</h2><p>${esc(v.p)}</p></div>
    <span class="tag">${esc(meta.source === 'sample' ? 'Sample scan' : meta.source === 'photo' ? 'Photo scan' : 'Text scan')}</span>
  </div>`);

  out.push(`<div class="panel"><div class="ph"><span class="eyebrow">Declaration</span>
      <span class="count">${esc(r.title)}</span></div>
    <div class="pb"><div class="decl">
      <div class="box"><div class="dl">Contains</div>
        <div class="dv ${d.contains.length ? '' : 'none'}">${d.contains.length ? esc(d.contains.join(' · ')) : 'No regulated allergen found in the declared ingredients.'}</div></div>
      <div class="box"><div class="dl">May contain — cross-contact</div>
        <div class="dv ${d.may.length ? '' : 'none'}">${d.may.length ? esc(d.may.join(' · '))
          : r.cross.length ? 'Process risks found, but every allergen they touch is already declared above.'
          : 'No process risk detected from what was written.'}</div></div>
    </div></div></div>`);

  if (r.conflicts.length) {
    const seen = new Set();
    const rows = r.conflicts.filter(c => { const k = c.claim + c.allergen; if (seen.has(k)) return false; seen.add(k); return true; });
    out.push(`<div class="conflict">
      <h3>Label contradicts itself</h3>
      ${rows.map(c => `<p>Claims <code>${esc(c.claim)}</code> but the ingredients carry
        <strong>${esc(ALLERGENS[c.allergen].label.toLowerCase())}</strong> via <code>${esc(c.evidence.join(', '))}</code></p>`).join('')}
      <p style="margin-top:4px">Treat the claim as unverified until the supplier explains it.</p>
    </div>`);
  }

  // ledger
  const rows = REGULATED.filter(a => levelOf(a) || cross.has(a))
    .sort((a, b) => (LEVELS[levelOf(b)] || 0) - (LEVELS[levelOf(a)] || 0) || (mine.has(b) - mine.has(a)));
  if (rows.length) {
    out.push(`<div class="panel"><div class="ph"><span class="eyebrow">Allergen ledger</span>
      <span class="count">${rows.length} flagged of ${REGULATED.length} checked</span></div>
      <div class="pb flush"><div class="ledger">
      ${rows.map(a => {
        const f = r.found[a];
        const lv = f ? f.level : 'trace';
        const label = f ? LEVEL_WORD[f.level] : 'Cross-contact';
        const ev = f ? f.evidence.slice(0, 4).map(e => `<em>${esc(e.term)}</em>`).join(', ')
                     : esc(cross.get(a).map(c => c.trigger).join(', '));
        const why = f && f.notes.length ? f.notes[0] : (!f ? cross.get(a)[0].note : '');
        return `<div class="lrow ${mine.has(a) ? 'yours' : ''}">
          <div class="nm">${esc(ALLERGENS[a].label)}${mine.has(a) ? '<span class="yourtag">Yours</span>' : ''}</div>
          <div class="ev">${ev}</div>
          <span class="lv ${lv}">${esc(label)}</span>
          ${why ? `<div class="why">${esc(why)}</div>` : ''}
        </div>`;
      }).join('')}
      </div></div></div>`);
  }

  const diet = DIETARY.filter(a => levelOf(a));
  if (diet.length) {
    out.push(`<div class="panel"><div class="ph"><span class="eyebrow">Dietary flags</span></div>
      <div class="pb"><div class="chips">
      ${diet.map(a => `<span class="chip" style="cursor:default">${esc(ALLERGENS[a].label)} <span style="color:var(--muted)">${esc(r.found[a].evidence.slice(0, 2).map(e => e.term.toLowerCase()).join(', '))}</span></span>`).join('')}
      </div></div></div>`);
  }

  if (r.cross.length) {
    out.push(`<div class="panel"><div class="ph"><span class="eyebrow">Cross-contact</span>
      <span class="count">${r.cross.length} process risk${r.cross.length > 1 ? 's' : ''}</span></div>
      <div class="pb">${r.cross.map(c => `<div class="gap">
        <code>${esc(c.trigger)}</code>
        <span>${esc(c.note)} <strong style="color:var(--ink)">${esc(c.allergens.map(a => ALLERGENS[a].label).join(', '))}</strong></span>
      </div>`).join('')}</div></div>`);
  }

  out.push(renderSwaps());

  const allLines = [...r.ingredients, ...r.prep];
  out.push(`<div class="panel"><div class="ph"><span class="eyebrow">What was read</span>
      <span class="count">${r.counts.ingredients} ingredient lines</span></div>
    <div class="pb flush"><ul class="deck">
      ${allLines.map(l => `<li class="${l.prep ? 'handling' : ''}">${markup(l)}</li>`).join('')}
    </ul></div></div>`);

  out.push(`<div class="panel"><div class="ph"><span class="eyebrow">What this scan can't see</span>
      <span class="count">Read confidence ${conf.score}%</span></div>
    <div class="pb">
      <div class="meter"><i class="${conf.score > 75 ? '' : conf.score > 45 ? 'mid' : 'low'}" style="width:${conf.score}%"></i></div>
      ${conf.gaps.length
        ? `<div class="gaps">${conf.gaps.map(([t, w]) => `<div class="gap"><code>${esc(t)}</code><span>${esc(w)}</span></div>`).join('')}</div>`
        : `<p class="note">Every ingredient resolved to a named substance. No vague terms on this label.</p>`}
      ${r.cleared.length ? `<p class="note">${r.cleared.length} match${r.cleared.length > 1 ? 'es' : ''} cleared by an on-pack free-from claim: ${esc([...new Set(r.cleared.map(c => c.term + ' → ' + c.claim))].join(', '))}.</p>` : ''}
    </div></div>`);

  out.push(`<div class="panel"><div class="ph"><span class="eyebrow">Kitchen tools</span>
      <span class="count">Free while in beta</span></div>
    <div class="pb">
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn" id="exportBtn" type="button">Export allergen statement</button>
        <button class="btn" id="saveBtn" type="button">Save to library</button>
      </div>
      <p class="note">The statement is a plain-text file you can print or hand to an inspector. It lists what the item contains, what it may contain, and every term the supplier still needs to explain.</p>
      <div id="toolMsg" class="note" hidden></div>
    </div></div>`);

  out.push(`<div class="banner" style="padding:18px 20px">
    <b>Everything here is free right now.</b> If you cook for other people and this saves you work,
    say so — that decides what gets built next.
    <a href="${FEEDBACK_URL}" style="font-weight:600">Tell me what's missing</a>
  </div>`);

  $('report').innerHTML = out.join('');
  $('exportBtn').onclick = doExport;
  $('saveBtn').onclick = doSave;

  document.querySelectorAll('.seg button[data-mode]').forEach(b => {
    b.onclick = () => { state.swapMode = b.dataset.mode; LS.set('swapMode', state.swapMode); renderReport(); };
  });
  const cs = $('copySwapBtn');
  if (cs) cs.onclick = async () => {
    const msg = $('swapMsg'); msg.hidden = false;
    const text = swapText();
    try { await navigator.clipboard.writeText(text); msg.textContent = 'Copied.'; }
    catch (e) { msg.innerHTML = '<pre style="white-space:pre-wrap;font-family:var(--mono);font-size:11.5px;margin:8px 0 0">' + esc(text) + '</pre>'; }
  };
}

/* ============================================================
   PRO TOOLS
   ============================================================ */
function statementText() {
  const r = state.result, d = declaration();
  const today = new Date().toISOString().slice(0, 10);
  const L = [];
  L.push('ALLERGEN STATEMENT');
  L.push('='.repeat(52));
  L.push('Item:      ' + r.title);
  L.push('Issued:    ' + today);
  L.push('Method:    Ingredient-declaration review (Allergen Sweep)');
  L.push('');
  L.push('CONTAINS: ' + (d.contains.length ? d.contains.join(', ').toUpperCase() : 'NONE DECLARED'));
  L.push('');
  L.push('MAY CONTAIN (cross-contact): ' + (d.may.length ? d.may.join(', ').toUpperCase() : 'NONE IDENTIFIED'));
  if (r.cross.length) {
    L.push('');
    L.push('PROCESS RISK NOTES');
    r.cross.forEach(c => L.push('  - [' + c.trigger + '] ' + c.note));
  }
  L.push('');
  L.push('INGREDIENT DECLARATION AS REVIEWED');
  r.ingredients.forEach(l => L.push('  - ' + l.text));
  if (r.prep.length) { L.push(''); L.push('HANDLING NOTES'); r.prep.forEach(l => L.push('  - ' + l.text)); }
  if (r.vague.length) {
    L.push('');
    L.push('UNRESOLVED TERMS — supplier confirmation required');
    r.vague.forEach(v => L.push('  - ' + v.t + ': ' + v.why));
  }
  L.push('');
  L.push('This statement reflects the ingredient declaration reviewed on the date above.');
  L.push('It is not a laboratory result and does not certify the absence of any allergen.');
  return L.join('\n');
}

function download(filename, text) {
  const url = URL.createObjectURL(new Blob([text], { type: 'text/plain;charset=utf-8' }));
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

function doExport() {
  const msg = $('toolMsg');
  msg.hidden = false;
  const name = state.result.title.replace(/[^\w]+/g, '-').toLowerCase().replace(/^-|-$/g, '').slice(0, 40) || 'recipe';
  download(name + '-allergen-statement.txt', statementText());
  msg.textContent = 'Statement downloaded.';
}

function doSave() {
  const msg = $('toolMsg');
  msg.hidden = false;
  const d = declaration();
  state.library.unshift({
    title: state.result.title, at: Date.now(),
    contains: d.contains.map(s => s.replace(/\s*\(.*$/, '')), may: d.may,
  });
  state.library = state.library.slice(0, 40);
  LS.set('library', state.library);
  renderLibrary();
  msg.textContent = 'Saved to your library.';
}

function renderLibrary() {
  const body = $('libBody');
  $('libCount').textContent = state.library.length ? state.library.length + ' saved' : '';
  if (!state.library.length) {
    body.innerHTML = '<p class="note">Nothing saved yet. Scan something and hit Save to library. Saved recipes live in this browser only — clearing site data clears them.</p>';
    return;
  }
  body.innerHTML = '<div class="gaps">' + state.library.map((x, i) => `<div class="gap">
      <code>${new Date(x.at).toISOString().slice(5, 10)}</code>
      <span><strong style="color:var(--ink)">${esc(x.title)}</strong><br>${esc(x.contains.join(', ') || 'no allergens')}</span>
    </div>`).join('') + '</div>'
    + '<button class="btn sm" id="clearLibBtn" type="button" style="align-self:flex-start;margin-top:4px">Clear library</button>';
  const cb = $('clearLibBtn');
  if (cb) cb.onclick = () => { state.library = []; LS.set('library', []); renderLibrary(); };
}

/* ============================================================
   IMAGE CAPTURE
   ============================================================ */
function addFiles(files) {
  const list = [...files].filter(f => /^image\//.test(f.type)).slice(0, 4 - state.images.length);
  for (const f of list) {
    const rd = new FileReader();
    rd.onload = () => { state.images.push({ file: f, url: rd.result }); renderShots(); };
    rd.readAsDataURL(f);
  }
}
function renderShots() {
  $('shots').innerHTML = state.images.map((im, i) =>
    `<div class="shot"><img src="${im.url}" alt="page ${i + 1}"><button type="button" data-i="${i}" aria-label="Remove">×</button></div>`).join('');
  $('shots').querySelectorAll('button').forEach(b => b.onclick = () => { state.images.splice(+b.dataset.i, 1); renderShots(); });
  $('scanBtn').disabled = !state.images.length;
  $('scanBtn').textContent = state.images.length > 1 ? `Scan ${state.images.length} photos` : 'Scan photo';
}
$('fileIn').onchange = e => { addFiles(e.target.files); e.target.value = ''; };
$('camIn').onchange = e => { addFiles(e.target.files); e.target.value = ''; };
const drop = $('drop');
['dragenter', 'dragover'].forEach(t => drop.addEventListener(t, e => { e.preventDefault(); drop.classList.add('over'); }));
['dragleave', 'drop'].forEach(t => drop.addEventListener(t, e => { e.preventDefault(); drop.classList.remove('over'); }));
drop.addEventListener('drop', e => addFiles(e.dataTransfer.files));
window.addEventListener('paste', e => { if (e.clipboardData?.files?.length) addFiles(e.clipboardData.files); });

/* ============================================================
   SCANNING
   ============================================================ */
const READ_PROMPT = `You are transcribing a photograph of food packaging, a recipe card, a menu, or a screenshot of one.

Transcribe only what is actually written or clearly shown. Never infer, complete, or correct an ingredient that is not legible — an invented ingredient on an allergy report is dangerous.

Reply with only this JSON:
{"title": string, "ingredients": [string], "prep": [string], "claims": [string], "legibility": "clear"|"partial"|"poor", "unreadable": [string]}

- title: what the item is called, or a short description of the dish
- ingredients: one entry per ingredient, exactly as written, keeping sub-ingredients in their parentheses
- prep: cooking, handling or facility statements ("made on equipment that also processes...", "deep fried")
- claims: free-from, vegan, kosher, halal or dietary claims printed on the item
- legibility: how well you could read it
- unreadable: short descriptions of any portion you could not make out

Example: {"title":"Granola Bar","ingredients":["rolled oats","honey","soy lecithin"],"prep":["Made on shared equipment"],"claims":["gluten-free"],"legibility":"clear","unreadable":[]}`;

/**
 * Shrink before upload. A 12MP phone photo costs the same to read as a 2MP one
 * and takes ten times longer to send, so this pays for itself on every scan.
 */
function downscale(file, maxEdge = 1600, quality = 0.85) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(url);
      const scale = Math.min(1, maxEdge / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * scale);
      c.height = Math.round(img.height * scale);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      resolve({
        mediaType: 'image/jpeg',
        data: c.toDataURL('image/jpeg', quality).split(',')[1],
      });
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('decode_failed')); };
    img.src = url;
  });
}

async function scanPhotos() {
  const btn = $('scanBtn'), msg = $('scanMsg');
  state.ctl = new AbortController();
  btn.disabled = true;
  btn.innerHTML = '<span class="spin"></span> Reading the label…';
  msg.hidden = false; msg.className = 'note';
  msg.textContent = 'Transcribing the photo. The allergen rules then run on your device.';

  try {
    const images = [];
    for (const im of state.images.slice(0, 4)) images.push(await downscale(im.file));

    const res = await fetch('/api/scan', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ images }),
      signal: state.ctl.signal,
    });
    const body = await res.json().catch(() => ({ error: 'bad_response' }));
    if (!res.ok) throw Object.assign(new Error(body.error || 'failed'), { code: body.error, status: res.status });

    state.result = analyze(body);
    state.meta = { source: 'photo', legibility: body.legibility, unreadable: body.unreadable || [] };
    renderReport();
    msg.hidden = true;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  } catch (e) {
    msg.className = 'err';
    msg.textContent = {
      rate_limited: 'That is a lot of scans in a short time. Give it a minute.',
      no_api_key: 'The scanner is not configured yet — the site owner needs to add an API key.',
      too_large: 'That photo is too big even after shrinking. Try a single, closer shot.',
      unreadable: 'Nothing readable came back. Re-shoot it straight on, in even light, filling the frame.',
      decode_failed: 'That file could not be opened as an image. Try a JPEG or PNG.',
      upstream: 'The reading service is having a moment. Try again shortly.',
    }[e.code] || (e.name === 'AbortError' ? 'Scan stopped.' : 'The scan failed. Try again, or paste the ingredients instead.');
  } finally {
    btn.disabled = !state.images.length;
    btn.textContent = state.images.length > 1 ? `Scan ${state.images.length} photos` : 'Scan photo';
  }
}
$('scanBtn').onclick = scanPhotos;

// split an ingredient run on commas, but never inside a sub-ingredient bracket
function splitTopLevel(s) {
  const out = []; let depth = 0, cur = '';
  for (const ch of s) {
    if (ch === '(' || ch === '[') depth++;
    else if (ch === ')' || ch === ']') depth = Math.max(0, depth - 1);
    if ((ch === ',' || ch === ';') && depth === 0) { out.push(cur); cur = ''; continue; }
    cur += ch;
  }
  out.push(cur);
  return out.map(x => x.trim().replace(/\.$/, '')).filter(Boolean);
}

// Read a pasted label the way it is actually printed: an INGREDIENTS run,
// a CONTAINS line, a MAY CONTAIN line, and any free-from claims.
function parseLabel(raw) {
  const claims = [], prep = [], blob = [];
  let title = '';
  const lines = raw.split(/\r?\n+/).map(s => s.trim()).filter(Boolean);
  for (const ln of lines) {
    if (/^(may contain|made (in|on)|manufactured (in|on)|processed (in|on)|produced (in|on)|packed in|prepared in)/i.test(ln)) { prep.push(ln); continue; }
    if (/^contains\b/i.test(ln)) { blob.push(ln.replace(/^contains:?\s*/i, '')); continue; }
    if (/^ingredients?\b/i.test(ln)) { blob.push(ln.replace(/^ingredients?:?\s*/i, '')); continue; }
    if (ln.length < 44 && /(gluten|dairy|nut|peanut|egg|soy|sesame|milk)[\s-]?free|^vegan$|^halal$|^kosher$|plant[- ]based/i.test(ln)) { claims.push(ln); continue; }
    if (!title && lines.length > 1 && ln.length < 52 && !/[,:;]/.test(ln)) { title = ln; continue; }
    blob.push(ln);
  }
  let ingredients = [];
  for (const b of blob) ingredients.push(...(b.includes(',') || b.length > 70 ? splitTopLevel(b) : [b]));
  ingredients = ingredients.map(s => s.replace(/\.$/, '').trim()).filter(Boolean);
  // ALL-CAPS labels read badly in the report; keep the words, soften the case
  ingredients = ingredients.map(s => (s === s.toUpperCase() && s.length > 2)
    ? s.toLowerCase().replace(/(^|[(,]\s*)([a-z])/g, (m, p, c) => p + c.toUpperCase()) : s);
  return { title: title || 'Pasted label', ingredients, prep, claims };
}

$('textBtn').onclick = () => {
  const raw = $('textIn').value.trim();
  if (!raw) { $('textIn').focus(); return; }
  state.result = analyze(parseLabel(raw));
  state.meta = { source: 'text', legibility: 'clear' };
  renderReport();
  window.scrollTo({ top: 0, behavior: 'smooth' });
};

$('pasteBtn').onclick = async () => {
  try {
    const t = await navigator.clipboard.readText();
    if (t) { $('textIn').value = t; $('textBtn').click(); return; }
  } catch (e) { /* clipboard read is often blocked in a frame */ }
  $('textIn').focus();
};

/* ============================================================
   BOOT
   ============================================================ */
// Ask the server once whether photo reading is configured, so a misconfigured
// deploy says so instead of failing on the user's first scan.
async function checkPhotoSupport() {
  const hint = $('scanHint'), panel = document.querySelector('.p-capture');
  const set = (ok, txt) => {
    hint.className = 'hint' + (ok ? '' : ' off');
    hint.lastElementChild.textContent = txt;
    panel.dataset.mode = ok ? 'photo' : 'text';
  };
  try {
    const r = await fetch('/api/scan', { method: 'GET' });
    const j = await r.json();
    if (j.ready) return set(true, 'Photo reading ready — up to 4 photos a scan.');
    set(false, 'Photo reading is not switched on yet. Paste the label instead — it reads INGREDIENTS, CONTAINS and MAY CONTAIN lines.');
  } catch (e) {
    set(false, 'Photo reading is offline. Paste the label instead — it reads INGREDIENTS, CONTAINS and MAY CONTAIN lines.');
  }
}
checkPhotoSupport();

renderChips();
renderLibrary();
state.result = analyze(SAMPLE);
state.meta = { source: 'sample', legibility: 'clear' };
renderReport();
