/* ============================================================
   ALLERGEN SWEEP — detection engine
   Deterministic rulebook. No AI judgement in here on purpose:
   the photo read is AI, the ruling is a fixed table you can audit.
   ============================================================ */

const ALLERGENS = {
  milk:      { label: 'Milk',        group: 'regulated' },
  egg:       { label: 'Egg',         group: 'regulated' },
  peanut:    { label: 'Peanut',      group: 'regulated' },
  treenut:   { label: 'Tree nut',    group: 'regulated' },
  soy:       { label: 'Soy',         group: 'regulated' },
  wheat:     { label: 'Wheat',       group: 'regulated' },
  gluten:    { label: 'Gluten',      group: 'regulated' },
  fish:      { label: 'Fish',        group: 'regulated' },
  shellfish: { label: 'Crustacean',  group: 'regulated' },
  mollusc:   { label: 'Mollusc',     group: 'regulated' },
  sesame:    { label: 'Sesame',      group: 'regulated' },
  mustard:   { label: 'Mustard',     group: 'regulated' },
  celery:    { label: 'Celery',      group: 'regulated' },
  sulphite:  { label: 'Sulphites',   group: 'regulated' },
  lupin:     { label: 'Lupin',       group: 'regulated' },
  corn:      { label: 'Corn',        group: 'dietary' },
  nightshade:{ label: 'Nightshade',  group: 'dietary' },
  alcohol:   { label: 'Alcohol',     group: 'dietary' },
  pork:      { label: 'Pork',        group: 'dietary' },
  allium:    { label: 'Allium',      group: 'dietary' },
};

const LEVELS = { contains: 3, hidden: 2, possible: 1 };

const RULES = [];
function add(allergen, level, terms, note) {
  for (const t of terms) RULES.push({ a: allergen, l: level, t, n: note || '' });
}
// a rule that matches text but declares nothing — used to swallow decoys
// ("almond milk" must not read as dairy) because longer terms win first.
function decoy(terms) { for (const t of terms) RULES.push({ a: null, l: null, t, n: '' }); }

/* ---- decoys: longest-match-first means these consume the text ---- */
decoy([
  'coconut milk','coconut cream','coconut water','coconut oil','coconut flour','coconut sugar',
  'rice milk','hemp milk','flax milk','pea milk','oat milk','milk thistle','non-dairy milk',
  'cocoa butter','apple butter','butter lettuce','butternut squash','butter bean','butter beans',
  'cream of tartar','creamed corn','buckwheat','buckwheat flour','water chestnut','water chestnuts',
  'nutmeg','nutritional yeast','eggplant','egg plant','aubergine','coconut aminos',
  'rice flour','chickpea flour','gram flour','besan','tapioca flour','tapioca starch',
  'potato starch','arrowroot','sorghum flour','cassava flour','millet flour','teff flour',
  'peanut-free','nut-free','dairy-free','gluten-free','egg-free','soy-free','wheat-free',
  'certified gluten-free','sesame-free','shellfish-free','fish-free',
]);

/* ---- MILK ---- */
add('milk','contains',[
  'milk','whole milk','skim milk','2% milk','buttermilk','butter','ghee','clarified butter',
  'cream','heavy cream','whipping cream','sour cream','creme fraiche','crème fraîche','clotted cream',
  'half-and-half','half and half','cheese','cheddar','mozzarella','parmesan','parmigiano','pecorino',
  'romano','feta','ricotta','mascarpone','gouda','brie','camembert','gruyere','gruyère','provolone',
  'monterey jack','swiss cheese','blue cheese','gorgonzola','manchego','asiago','havarti','queso',
  'cream cheese','cottage cheese','yogurt','yoghurt','greek yogurt','kefir','skyr','quark',
  'custard','creme anglaise','condensed milk','evaporated milk','milk powder','milk solids',
  'nonfat dry milk','dry milk','dulce de leche','paneer','halloumi','burrata','mascarpone',
  'ice cream','gelato','milk chocolate','white chocolate','alfredo','bechamel','béchamel',
  'buttercream','ganache','nutella','curd','cheese powder',
]);
add('milk','hidden',[
  'casein','caseinate','sodium caseinate','calcium caseinate','rennet casein','caseinates',
  'whey','whey protein','whey powder','sweet whey','lactose','lactalbumin','lactoglobulin',
  'milkfat','milk fat','butterfat','butter oil','butter solids','anhydrous milk fat',
  'curds','milk protein concentrate','recaldent','tagatose',
], 'Dairy derivative — routinely missed on ingredient decks.');
add('milk','possible',[
  'natural flavor','natural flavors','natural flavour','artificial flavor','flavoring','flavouring',
  'margarine','butter flavor','lactic acid','caramel','nougat','shortening','chocolate',
  'dark chocolate','chocolate chips','creamer','non-dairy creamer','brown butter solids',
], 'Common but not guaranteed carrier of milk protein — confirm with the supplier.');

/* ---- EGG ---- */
add('egg','contains',[
  'egg','eggs','egg white','egg whites','egg yolk','egg yolks','whole egg','dried egg','egg powder',
  'powdered egg','liquid egg','egg wash','meringue','mayonnaise','mayo','aioli','hollandaise',
  'frittata','omelet','omelette','quiche','egg noodle','egg noodles','pasteurized egg',
  'custard','creme brulee','crème brûlée','zabaglione','egg substitute is not egg',
]);
add('egg','hidden',[
  'albumen','albumin','ovalbumin','ovomucoid','ovovitellin','globulin','livetin','vitellin',
  'lysozyme','apovitellin','silici albuminate','simplesse',
], 'Egg protein under its lab name.');
add('egg','possible',[
  'marshmallow','nougat','lecithin','royal icing','pasta','fresh pasta','tempura','surimi',
], 'Frequently but not always egg-based.');

/* ---- PEANUT ---- */
add('peanut','contains',[
  'peanut','peanuts','peanut butter','peanut oil','peanut flour','groundnut','groundnuts',
  'arachis oil','beer nuts','monkey nut','mandelona','satay','satay sauce','peanut sauce',
]);
add('peanut','possible',[
  'mixed nuts','nut butter','mole','mole sauce','pad thai','trail mix','artificial nuts',
  'hydrolyzed plant protein','chili oil',
], 'Peanut is a common component or shared-line neighbour here.');

/* ---- TREE NUT ---- */
add('treenut','contains',[
  'almond','almonds','almond flour','almond meal','almond milk','almond butter','almond paste',
  'almond extract','marzipan','frangipane','amaretto','amaretti','cashew','cashews','cashew milk',
  'cashew butter','walnut','walnuts','pecan','pecans','pistachio','pistachios','hazelnut','hazelnuts',
  'filbert','filberts','macadamia','macadamia nut','brazil nut','brazil nuts','pine nut','pine nuts',
  'pignoli','chestnut','chestnuts','praline','gianduja','nut','nuts','tree nut','tree nuts',
  'nut meal','nut flour','nut paste','hazelnut spread','pistachio paste','pesto','baklava',
  'nut oil','walnut oil','almond oil',
]);
add('treenut','possible',[
  'coconut','shea','shea butter','nougat','mixed nuts','marzipan substitute','natural flavor',
], 'FDA lists coconut as a tree nut; most coconut-allergic reactions are unrelated to nut allergy. Flagged for completeness.');

/* ---- SOY ---- */
add('soy','contains',[
  'soy','soya','soybean','soybeans','soy sauce','soy protein','soy flour','soy milk','soybean oil',
  'tofu','bean curd','tempeh','edamame','natto','miso','miso paste','tamari','shoyu','hoisin',
  'hoisin sauce','teriyaki','teriyaki sauce','ponzu','okara','yuba','textured vegetable protein',
  'tvp','hydrolyzed soy protein','soy lecithin','soy isolate','soy protein isolate',
]);
add('soy','hidden',[
  'lecithin','mono- and diglycerides','monoglycerides','diglycerides','hydrolyzed vegetable protein',
  'vegetable protein','e322',
], 'Usually soy-derived unless the supplier states otherwise.');
add('soy','possible',[
  'vegetable broth','vegetable oil','emulsifier','shortening','natural flavor','bouillon',
], 'Soy is the default input, though refining usually strips the protein.');

/* ---- WHEAT + GLUTEN ---- */
const WHEAT_TERMS = [
  'wheat','wheat flour','whole wheat','white flour','all-purpose flour','all purpose flour',
  'bread flour','cake flour','pastry flour','self-rising flour','self-raising flour','flour',
  'enriched flour','graham flour','semolina','durum','durum wheat','farina','spelt','kamut',
  'khorasan','einkorn','emmer','farro','bulgur','couscous','freekeh','seitan','vital wheat gluten',
  'wheat gluten','wheat starch','wheat germ','wheat bran','wheat protein','matzo','matzoh','matzah',
  'panko','breadcrumb','breadcrumbs','bread crumbs','bread','brioche','challah','baguette',
  'pasta','spaghetti','macaroni','penne','fettuccine','lasagna','lasagne','udon','ramen','soba',
  'phyllo','filo','puff pastry','pastry','croissant','cracker','crackers','pretzel','pretzels',
  'pie crust','roux','tempura','wonton','wonton wrapper','dumpling wrapper','flour tortilla',
  'pita','naan','focaccia','ciabatta','bagel','biscuit','scone','crouton','croutons','cereal',
  'egg noodle','egg noodles','wheat noodles','chow mein','orzo','gnocchi','pierogi',
];
add('wheat','contains', WHEAT_TERMS);
add('gluten','contains', WHEAT_TERMS);
add('gluten','contains',[
  'barley','malt','malted','malt extract','malt syrup','malt vinegar','malted barley','rye',
  'pumpernickel','triticale','brewer’s yeast','brewers yeast','beer','ale','lager','stout','porter',
]);
add('gluten','possible',[
  'oats','oat','rolled oats','oat flour','oatmeal','steel-cut oats','granola','muesli','quinoa',
  'modified food starch','food starch','dextrin','maltodextrin','starch','seasoning','spice blend',
  'bouillon','stock cube','soy sauce','imitation crab','surimi','licorice','communion wafer',
], 'Gluten-free in itself, but sourced through shared milling or blended with wheat in most supply chains.');
add('wheat','possible',[
  'noodles','tortilla','dumpling','spring roll wrapper','modified food starch','soy sauce',
  'hoisin','teriyaki','surimi','imitation crab','miso',
]);

/* ---- FISH ---- */
add('fish','contains',[
  'fish','anchovy','anchovies','salmon','tuna','cod','haddock','halibut','tilapia','sea bass',
  'trout','sardine','sardines','mackerel','snapper','sole','catfish','pollock','pollack','mahi',
  'swordfish','herring','bonito','bonito flakes','katsuobushi','dashi','fish sauce','nam pla',
  'fish stock','fish oil','caviar','roe','ikura','surimi','worcestershire','worcestershire sauce',
  'caesar dressing','caesar','garum','colatura','anchovy paste','nuoc mam',
]);
add('fish','possible',[
  'omega-3','omega 3','gelatin','seafood','marinara','puttanesca','xo sauce','oyster sauce',
], 'Fish-derived in many commercial formulations.');

/* ---- CRUSTACEAN ---- */
add('shellfish','contains',[
  'shrimp','shrimps','prawn','prawns','crab','crabmeat','crab meat','lobster','langoustine',
  'crawfish','crayfish','krill','shellfish','scampi','shrimp paste','belacan','crab stick',
  'imitation crab','bisque','bouillabaisse','chitin','glucosamine',
]);
add('shellfish','possible',[
  'seafood','xo sauce','fish sauce','surimi','seafood stock','paella',
], 'Crustacean stock or flavour base is standard in this preparation.');

/* ---- MOLLUSC ---- */
add('mollusc','contains',[
  'oyster','oysters','oyster sauce','clam','clams','mussel','mussels','scallop','scallops',
  'squid','calamari','octopus','snail','escargot','abalone','cuttlefish','whelk','periwinkle',
  'clam juice','clam broth',
]);

/* ---- SESAME ---- */
add('sesame','contains',[
  'sesame','sesame seed','sesame seeds','sesame oil','toasted sesame oil','tahini','tahina',
  'halva','halvah','benne','benne seed','gingelly','til','sesamol','sesamum','gomashio',
  'za’atar','zaatar','za atar','everything bagel','everything seasoning','hummus','baba ganoush',
]);
add('sesame','possible',[
  'burger bun','brioche bun','bun','buns','falafel','dukkah','tempeh burger','sushi',
  'spice blend','seasoning','flatbread',
], 'Sesame is a default topping or blend component here and is often undeclared.');

/* ---- MUSTARD / CELERY / SULPHITE / LUPIN ---- */
add('mustard','contains',[
  'mustard','dijon','dijon mustard','mustard seed','mustard seeds','mustard powder','mustard oil',
  'honey mustard','whole grain mustard','yellow mustard','english mustard',
]);
add('mustard','possible',['curry powder','piccalilli','barbecue sauce','bbq sauce','remoulade','vinaigrette']);
add('celery','contains',[
  'celery','celeriac','celery salt','celery seed','celery root','celery powder','mirepoix',
]);
add('celery','possible',['vegetable stock','vegetable broth','bouillon','stock cube','mirepoix base']);
add('sulphite','contains',[
  'sulphite','sulfite','sulfites','sulphites','sodium metabisulfite','potassium metabisulfite',
  'sodium bisulfite','potassium bisulfite','sulfur dioxide','sulphur dioxide','e220','e221','e222',
  'e223','e224','e225','e226','e227','e228',
]);
add('sulphite','possible',[
  'wine','red wine','white wine','vinegar','balsamic vinegar','dried apricot','dried apricots',
  'dried fruit','raisins','molasses','grape juice','cider','maraschino cherries','pickles',
], 'Sulphites are used as a preservative here more often than not.');
add('lupin','contains',['lupin','lupine','lupin flour','lupini','lupini beans']);

/* ---- DIETARY FLAGS ---- */
add('corn','contains',[
  'corn','cornstarch','corn starch','corn syrup','high fructose corn syrup','corn flour','cornmeal',
  'corn meal','maize','masa','masa harina','polenta','grits','hominy','corn oil','popcorn',
  'corn tortilla','corn syrup solids',
]);
add('corn','possible',['dextrose','maltodextrin','xanthan gum','citric acid','caramel color','modified food starch','baking powder','vanilla extract']);
add('nightshade','contains',[
  'tomato','tomatoes','tomato paste','tomato sauce','potato','potatoes','bell pepper','bell peppers',
  'paprika','smoked paprika','cayenne','chili','chilli','chilies','chiles','chipotle','jalapeno',
  'jalapeño','ancho','goji','goji berry','tomatillo','pimento','pimiento','nightshade',
  'eggplant','egg plant','aubergine','poblano','serrano pepper','habanero','cherry tomato',
]);
add('alcohol','contains',[
  'wine','beer','rum','bourbon','whiskey','whisky','brandy','sherry','vodka','gin','mirin','sake',
  'cognac','marsala','port wine','kirsch','liqueur','triple sec','grand marnier',
]);
add('alcohol','possible',['vanilla extract','almond extract','extract','rum flavoring']);
add('pork','contains',[
  'pork','bacon','ham','prosciutto','pancetta','lard','chorizo','guanciale','speck','salami',
  'pepperoni','serrano ham','pork belly','pork fat','bratwurst',
]);
add('pork','possible',['gelatin','gelatine','rennet','natural casing','sausage','broth','stock','marshmallow']);
add('allium','contains',[
  'onion','onions','garlic','shallot','shallots','leek','leeks','chive','chives','scallion',
  'scallions','green onion','spring onion','garlic powder','onion powder','asafoetida',
]);

/* ---- cross-contact triggers: facility & process risk, not ingredients ---- */
const CROSS_CONTACT = [
  { test: /\b(deep[- ]?fr(y|ied|ying)|fryer|fried)\b/i, allergens: ['fish','shellfish','gluten','wheat'],
    note: 'Shared fryer oil. Battered fish, shrimp and breaded items transfer protein into oil that is rarely dedicated.' },
  { test: /\b(flour|dusted|dredge|dredged|floured)\b/i, allergens: ['wheat','gluten'],
    note: 'Airborne flour stays suspended for hours and settles on open product across the whole prep area.' },
  { test: /\b(oats|oat|oatmeal|granola|muesli)\b/i, allergens: ['gluten'], unless: /certified gluten[- ]free|gluten[- ]free oats|purity protocol/i,
    note: 'Oats are milled and rotated on wheat equipment. Only purity-protocol or certified GF oats clear this.' },
  { test: /\b(chocolate|cocoa|couverture|candy|confection)\b/i, allergens: ['milk','peanut','treenut'],
    note: 'Confectionery lines run milk and nut product on the same equipment between cleandowns.' },
  { test: /\b(bulk bin|bulk|scoop|scooped|self[- ]serve|salad bar|buffet)\b/i, allergens: ['peanut','treenut','gluten','sesame'],
    note: 'Shared scoops and open bins are the single most common source of consumer cross-contact.' },
  { test: /\b(spice blend|seasoning|seasoning blend|rub|curry powder|masala)\b/i, allergens: ['mustard','sesame','gluten','celery'],
    note: 'Blended spices are a black box: anti-caking agents and fillers carry wheat, mustard and sesame.' },
  { test: /\b(ice cream|gelato|soft serve|sundae)\b/i, allergens: ['peanut','treenut','milk','egg'],
    note: 'Shared scoops, rinse wells and topping stations.' },
  { test: /\b(grill|griddle|flat[- ]?top|plancha|wok)\b/i, allergens: ['gluten','soy','shellfish'],
    note: 'Shared cook surface. Soy-marinated and breaded items leave residue between services.' },
  { test: /\b(bakery|baked in|patisserie|pastry case|donut|doughnut)\b/i, allergens: ['treenut','milk','egg','wheat','sesame'],
    note: 'Open bakery cases share air, tongs and cooling racks across every product in the line.' },
  { test: /\b(smoothie|blender|blended|juice bar)\b/i, allergens: ['milk','treenut','peanut','soy'],
    note: 'Blender jars carry protein residue through a rinse; only a full wash clears them.' },
];

/* ---- vague terms: the data-risk list ---- */
const VAGUE = [
  { t: 'natural flavor', why: 'Can legally contain milk or fish protein without naming it.' },
  { t: 'natural flavors', why: 'Can legally contain milk or fish protein without naming it.' },
  { t: 'artificial flavor', why: 'Carrier solvent and base are undeclared.' },
  { t: 'flavoring', why: 'Undeclared carrier; commonly dairy or alcohol based.' },
  { t: 'spices', why: 'Blend composition is a trade secret; fillers vary by lot.' },
  { t: 'seasoning', why: 'Blend composition is a trade secret; fillers vary by lot.' },
  { t: 'spice blend', why: 'Blend composition is a trade secret; fillers vary by lot.' },
  { t: 'modified food starch', why: 'Wheat-derived outside the US unless the source is stated.' },
  { t: 'food starch', why: 'Source grain is not declared.' },
  { t: 'starch', why: 'Source grain is not declared.' },
  { t: 'lecithin', why: 'Soy or egg derived — the source decides whether this matters.' },
  { t: 'mono- and diglycerides', why: 'Can be soy or dairy derived.' },
  { t: 'emulsifier', why: 'Unnamed; soy lecithin is the default in most plants.' },
  { t: 'vegetable oil', why: 'Blend may include peanut or soybean oil.' },
  { t: 'vegetable broth', why: 'Celery and soy are standard base components.' },
  { t: 'shortening', why: 'May be dairy or palm based; historically animal fat.' },
  { t: 'enzymes', why: 'Culture medium can be dairy or wheat derived.' },
  { t: 'glaze', why: 'Composition unstated; egg wash and dairy are typical.' },
  { t: 'colour added', why: 'Carrier undeclared.' },
  { t: 'color added', why: 'Carrier undeclared.' },
  { t: 'proprietary blend', why: 'Nothing about this is verifiable from the label.' },
  { t: 'and other ingredients', why: 'Incomplete declaration — treat the whole scan as provisional.' },
];

/* ---- free-from claims ---- */
const CLAIMS = [
  { t: /\bgluten[- ]?free\b/i, id: 'gluten-free', excludes: ['gluten','wheat'] },
  { t: /\bdairy[- ]?free\b/i, id: 'dairy-free', excludes: ['milk'] },
  { t: /\bmilk[- ]?free\b/i, id: 'milk-free', excludes: ['milk'] },
  { t: /\bnut[- ]?free\b/i, id: 'nut-free', excludes: ['treenut','peanut'] },
  { t: /\bpeanut[- ]?free\b/i, id: 'peanut-free', excludes: ['peanut'] },
  { t: /\begg[- ]?free\b/i, id: 'egg-free', excludes: ['egg'] },
  { t: /\bsoy[- ]?free\b/i, id: 'soy-free', excludes: ['soy'] },
  { t: /\bsesame[- ]?free\b/i, id: 'sesame-free', excludes: ['sesame'] },
  { t: /\bvegan\b/i, id: 'vegan', excludes: ['milk','egg','fish','shellfish','mollusc','pork'] },
  { t: /\bplant[- ]?based\b/i, id: 'plant-based', excludes: ['milk','egg','fish','shellfish','mollusc','pork'] },
  { t: /\bkosher\b/i, id: 'kosher', excludes: ['pork','shellfish','mollusc'] },
  { t: /\bhalal\b/i, id: 'halal', excludes: ['pork','alcohol'] },
];

/* ---- matcher ---- */
function escRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

/* One term can carry several allergens at once: "soy sauce" is soy AND wheat,
   "semolina" is wheat AND gluten. Group the rulebook by term so a single
   match in the text emits every allergen that term implies. */
const BY_TERM = new Map();
for (const r of RULES) {
  const k = r.t.toLowerCase();
  if (!BY_TERM.has(k)) BY_TERM.set(k, { t: r.t, rules: [] });
  if (r.a) BY_TERM.get(k).rules.push({ a: r.a, l: r.l, n: r.n });
}
const COMPILED = [...BY_TERM.values()]
  .sort((a, b) => b.t.length - a.t.length)
  .map(x => ({ ...x, re: new RegExp('\\b' + escRe(x.t) + (/s$/.test(x.t) ? '' : '(?:e?s)?') + '\\b', 'gi') }));

// "gluten-free flour", "dairy-free chocolate": the claim qualifies the very
// next ingredient, so the term is not evidence of the allergen it names.
const FREE_BEFORE = /([a-z]+)\s*-\s*free,?\s+(?:[a-z]+\s+){0,2}$/i;
const FREE_CLAIM_MAP = {
  gluten: ['gluten','wheat'], wheat: ['wheat','gluten'], dairy: ['milk'], milk: ['milk'],
  nut: ['treenut','peanut'], peanut: ['peanut'], egg: ['egg'], soy: ['soy'],
  sesame: ['sesame'], fish: ['fish'], shellfish: ['shellfish','mollusc'], corn: ['corn'],
};

function scanLine(text) {
  const taken = [];
  const hits = [];
  const cleared = [];
  const overlaps = (s, e) => taken.some(([ts, te]) => s < te && e > ts);
  for (const r of COMPILED) {
    r.re.lastIndex = 0;
    let m;
    while ((m = r.re.exec(text)) !== null) {
      const s = m.index, e = s + m[0].length;
      // "sugar-free", "nut-free": the claim is not the ingredient
      if (/^-\s*free\b/i.test(text.slice(e, e + 7))) continue;
      // don't match the tail of a longer hyphenated compound
      if (text[s - 1] === '-' || text[s - 1] === '_') continue;
      if (overlaps(s, e)) continue;
      taken.push([s, e]);
      if (!r.rules.length) continue;

      const pre = FREE_BEFORE.exec(text.slice(Math.max(0, s - 40), s));
      const waived = pre ? (FREE_CLAIM_MAP[pre[1].toLowerCase()] || []) : [];
      for (const rule of r.rules) {
        if (waived.includes(rule.a)) {
          cleared.push({ a: rule.a, term: m[0], claim: pre[1].toLowerCase() + '-free' });
          continue;
        }
        hits.push({ a: rule.a, l: rule.l, term: m[0], note: rule.n, start: s, end: e });
      }
    }
  }
  hits.sort((x, y) => x.start - y.start);
  return { hits, cleared };
}

function analyze(input) {
  const ingredients = (input.ingredients || []).map(s => String(s).trim()).filter(Boolean);
  const prep = (input.prep || []).map(s => String(s).trim()).filter(Boolean);
  const whole = [ingredients.join('\n'), prep.join('\n'), (input.claims || []).join('\n')].join('\n');

  const lines = ingredients.map(text => ({ text, ...scanLine(text) }));
  const prepLines = prep.map(text => ({ text, ...scanLine(text), prep: true }));
  const cleared = [...lines, ...prepLines].flatMap(l => l.cleared);

  // An allergen named in a shared-facility line is a contact risk, not an
  // ingredient. "Baked alongside hazelnut danish" must never read as CONTAINS.
  const FACILITY = /\b(shared|shares|sharing|also (processes|handles|produces|made|baked)|same (line|equipment|facility|fryer|surface)|made in a facility|may contain|cross[- ]?contact|equipment that also|alongside)\b/i;
  for (const ln of prepLines) {
    if (!FACILITY.test(ln.text)) continue;
    ln.facility = true;
    ln.hits = ln.hits.map(h => ({ ...h, l: 'possible',
      note: 'Named in a shared-facility statement, not in the ingredient declaration.' }));
  }

  const found = {};
  for (const ln of [...lines, ...prepLines]) {
    for (const h of ln.hits) {
      const cur = found[h.a] || (found[h.a] = { a: h.a, level: 'possible', evidence: [], hits: [] });
      if (LEVELS[h.l] > LEVELS[cur.level]) cur.level = h.l;
      cur.hits.push(h);
      if (!cur.evidence.some(e => e.term.toLowerCase() === h.term.toLowerCase())) {
        cur.evidence.push({ term: h.term, level: h.l, from: ln.text });
      }
    }
  }
  for (const k of Object.keys(found)) {
    const f = found[k];
    // only explain at the level the row is actually reported at
    f.notes = [...new Set(f.hits.filter(h => h.l === f.level && h.note).map(h => h.note))];
    f.evidence.sort((a, b) => LEVELS[b.level] - LEVELS[a.level]);
  }

  // cross-contact
  const cross = [];
  for (const cc of CROSS_CONTACT) {
    if (!cc.test.test(whole)) continue;
    if (cc.unless && cc.unless.test(whole)) continue;
    cross.push({ note: cc.note, allergens: cc.allergens, trigger: (whole.match(cc.test) || [''])[0] });
  }

  // claims + conflicts
  const claims = [];
  const conflicts = [];
  for (const c of CLAIMS) {
    if (!c.t.test(whole)) continue;
    claims.push(c.id);
    for (const a of c.excludes) {
      const f = found[a];
      if (f && LEVELS[f.level] >= 2) {
        conflicts.push({
          claim: c.id, allergen: a, level: f.level,
          evidence: f.evidence.slice(0, 3).map(e => e.term),
        });
      }
    }
  }

  // vague / data risk
  const lower = whole.toLowerCase();
  const vagueAll = VAGUE.filter(v => lower.includes(v.t));
  const vague = vagueAll.filter(v => !vagueAll.some(o => o !== v && o.t.includes(v.t)));

  return {
    title: input.title || 'Untitled recipe',
    ingredients: lines,
    prep: prepLines,
    found, cross, claims, conflicts, vague, cleared,
    counts: {
      ingredients: ingredients.length,
      resolved: lines.filter(l => l.hits.length).length,
      unresolved: vague.length,
    },
  };
}

/* ============================================================
   SUBSTITUTIONS
   What to put in instead. Ratios and behaviour notes matter more
   than the swap itself — a 1:1 swap that ruins the bake is not help.
   ============================================================ */
const SUBS = {};
function sub(terms, fixes, swaps, caveat) {
  for (const t of terms) SUBS[t.toLowerCase()] = { fixes, swaps, caveat: caveat || '' };
}

/* --- milk --- */
sub(['butter','clarified butter','ghee'], ['milk'], [
  { use: 'Vegan butter block', ratio: '1:1', note: 'Use a block, not a tub — tubs carry more water and slacken doughs.' },
  { use: 'Refined coconut oil', ratio: '1:1', note: 'Refined, not virgin, or it tastes of coconut. Solid at room temp, so it creams like butter.' },
  { use: 'Olive oil', ratio: '¾ of the butter weight', note: 'Savoury cooking only.' },
]);
sub(['milk','whole milk','skim milk','2% milk'], ['milk'], [
  { use: 'Soy milk, unsweetened', ratio: '1:1', note: 'Highest protein of the plant milks, so it browns and sets closest to dairy.' },
  { use: 'Oat milk', ratio: '1:1', note: 'Sweeter and starchier. Best in bakes and coffee.' },
]);
sub(['cream','heavy cream','whipping cream','half-and-half','half and half'], ['milk'], [
  { use: 'Full-fat coconut cream', ratio: '1:1', note: 'Chill the tin overnight and it whips. Leaves a light coconut note.' },
  { use: 'Oat barista cream', ratio: '1:1', note: 'Neutral, will not whip — use where cream is poured, not piped.' },
]);
sub(['buttermilk'], ['milk'], [
  { use: 'Soy milk + acid', ratio: '1 cup milk + 1 tbsp lemon juice or vinegar', note: 'Stand 10 minutes until it curdles. Soy curdles best.' },
]);
sub(['sour cream','creme fraiche','crème fraîche','yogurt','yoghurt','greek yogurt'], ['milk'], [
  { use: 'Unsweetened coconut or soy yogurt', ratio: '1:1', note: 'Check it is plain — vanilla is the usual default on the shelf.' },
]);
sub(['cream cheese','mascarpone'], ['milk'], [
  { use: 'Vegan cream cheese', ratio: '1:1', note: 'Cashew-based versions are common — avoid those on a tree-nut plan.' },
]);
sub(['parmesan','parmigiano','pecorino','romano','cheese powder'], ['milk'], [
  { use: 'Nutritional yeast + salt', ratio: '¼ of the volume', note: 'Carries the savoury note, none of the melt.' },
  { use: 'Commercial vegan parmesan', ratio: '1:1', note: '' },
]);
sub(['cheese','cheddar','mozzarella','gouda','provolone','monterey jack','queso','swiss cheese'], ['milk'], [
  { use: 'Starch-based vegan cheese', ratio: '1:1', note: 'Melts at a higher temperature. Add a teaspoon of oil and cover the pan.' },
]);
sub(['whey','whey protein','whey powder','milk powder','milk solids','nonfat dry milk','dry milk','milk protein concentrate'], ['milk'], [
  { use: 'Pea protein isolate', ratio: '1:1 by weight', note: 'Matches the protein, not the sweetness — add 10% more sugar if it was a milk powder.' },
]);
sub(['condensed milk','evaporated milk'], ['milk'], [
  { use: 'Coconut condensed milk', ratio: '1:1', note: '' },
]);
sub(['ice cream','gelato'], ['milk'], [
  { use: 'Oat or coconut frozen dessert', ratio: '1:1', note: 'Oat bases stay softer out of the freezer.' },
]);
sub(['milk chocolate','white chocolate'], ['milk'], [
  { use: 'Oat-milk chocolate', ratio: '1:1', note: 'Now widely stocked. Dark chocolate works too but shifts the sweetness.' },
]);

/* --- egg --- */
sub(['egg','eggs','whole egg','dried egg','egg powder','liquid egg','pasteurized egg'], ['egg'], [
  { use: 'Flax egg', ratio: '1 tbsp ground flaxseed + 3 tbsp water per egg', note: 'Rest 5 minutes to gel. Binds cookies, muffins and burgers well; will not lift a sponge.' },
  { use: 'Commercial egg replacer', ratio: 'per packet, usually 1½ tsp + 3 tbsp water', note: 'The most reliable swap in structure-critical baking.' },
  { use: 'Unsweetened applesauce', ratio: '¼ cup per egg', note: 'For moisture only. Adds sweetness — cut the sugar slightly.' },
], 'Two eggs is the practical ceiling. Beyond that the recipe is relying on egg for structure and needs reworking, not swapping.');
sub(['egg white','egg whites','meringue','albumen'], ['egg'], [
  { use: 'Aquafaba (chickpea tin liquid)', ratio: '3 tbsp per white', note: 'Whips to stiff peaks. Add ⅛ tsp cream of tartar for stability — it weeps sooner than egg.' },
]);
sub(['egg yolk','egg yolks'], ['egg'], [
  { use: 'Blended silken tofu', ratio: '2 tbsp per yolk', note: 'Covers richness and emulsifying. Set custards remain difficult.' },
]);
sub(['mayonnaise','mayo','aioli'], ['egg'], [
  { use: 'Aquafaba-based vegan mayo', ratio: '1:1', note: '' },
]);
sub(['egg wash'], ['egg'], [
  { use: 'Plant milk + a little maple syrup', ratio: 'brush on', note: 'Browns nearly as well. Aquafaba gives more shine, less colour.' },
]);
sub(['hollandaise'], ['egg'], [
  { use: 'Silken tofu + lemon + turmeric, blended warm', ratio: '1:1 by volume', note: 'Holds without splitting, which the original never does.' },
]);
sub(['custard','creme anglaise'], ['egg','milk'], [
  { use: 'Cornstarch-set coconut custard', ratio: '2 tbsp cornstarch per cup of liquid', note: 'Sets on cooling rather than on coagulation.' },
]);

/* --- wheat / gluten --- */
sub(['flour','all-purpose flour','all purpose flour','white flour','enriched flour','plain flour','cake flour','pastry flour','self-rising flour','self-raising flour','wheat flour','graham flour'], ['wheat','gluten'], [
  { use: '1:1 gluten-free baking blend', ratio: '1:1 by weight', note: 'Buy one that already lists xanthan gum. If it does not, add ¼ tsp per cup.' },
  { use: 'Oat flour (certified GF)', ratio: '1:1 by weight', note: 'Softer crumb, more liquid absorbed. Rest the batter 20 minutes.' },
], 'Gluten-free doughs do not develop structure by kneading. Mix less, hydrate more, and rest the batter before baking.');
sub(['bread flour','bread','brioche','challah','baguette','ciabatta','focaccia'], ['wheat','gluten'], [
  { use: 'GF bread blend + psyllium husk', ratio: '1:1 blend, plus 1 tbsp whole psyllium husk per 300g', note: 'Psyllium does the job gluten did. The dough will look like thick batter — that is correct.' },
]);
sub(['breadcrumb','breadcrumbs','bread crumbs','panko','crouton','croutons'], ['wheat','gluten'], [
  { use: 'GF panko', ratio: '1:1', note: '' },
  { use: 'Crushed cornflakes or rice cereal', ratio: '1:1', note: 'Crisper, browns faster — drop the oven 15°C.' },
]);
sub(['pasta','spaghetti','macaroni','penne','fettuccine','lasagna','lasagne','orzo'], ['wheat','gluten'], [
  { use: 'Chickpea or lentil pasta', ratio: '1:1', note: 'Holds sauce best and stays firm. Salt the water harder.' },
  { use: 'Brown rice pasta', ratio: '1:1', note: 'Closest in flavour. Rinse after draining or it claps together.' },
]);
sub(['soy sauce','shoyu'], ['wheat','gluten'], [
  { use: 'Tamari, certified gluten-free', ratio: '1:1', note: 'Still soy. For a soy plan as well, use coconut aminos.' },
]);
sub(['couscous','bulgur','farro','freekeh','semolina','durum'], ['wheat','gluten'], [
  { use: 'Quinoa or millet', ratio: '1:1 cooked volume', note: 'Cooking times differ — follow the grain, not the original recipe.' },
]);
sub(['barley','malt','malted','malt extract','malt vinegar','rye','pumpernickel'], ['gluten'], [
  { use: 'Sorghum or buckwheat', ratio: '1:1', note: 'For malt vinegar, use apple cider vinegar.' },
]);
sub(['oats','oat','rolled oats','oatmeal','oat flour','steel-cut oats','granola','muesli'], ['gluten'], [
  { use: 'Certified gluten-free oats', ratio: '1:1', note: 'Same oat, clean supply chain. This is the whole fix.' },
]);
sub(['beer','ale','lager','stout'], ['gluten'], [
  { use: 'Hard cider, or sparkling water', ratio: '1:1', note: 'In batter, sparkling water plus a pinch of baking powder gives the same lift.' },
]);
sub(['phyllo','filo','puff pastry','pastry','pie crust','tortilla','flour tortilla','pita','naan','wonton','dumpling wrapper'], ['wheat','gluten'], [
  { use: 'Gluten-free version of the same product', ratio: '1:1', note: 'Handle cold and work fast — there is no gluten holding it together.' },
]);
sub(['roux'], ['wheat','gluten'], [
  { use: 'Cornstarch slurry', ratio: 'half the flour weight, whisked into cold liquid', note: 'Add at the end, off the boil.' },
]);

/* --- soy --- */
sub(['soy','soya','soybean','soybeans','soy protein','soy flour','soy milk','soy isolate','soy protein isolate','textured vegetable protein','tvp'], ['soy'], [
  { use: 'Pea protein, or oat milk in liquid form', ratio: '1:1', note: '' },
]);
sub(['tofu','bean curd'], ['soy'], [
  { use: 'Chickpea tofu (burmese tofu)', ratio: '1:1', note: 'Softer set. Pan-fries well, will not hold up in a stew.' },
]);
sub(['tempeh','edamame','natto'], ['soy'], [
  { use: 'Lentils, or green peas for edamame', ratio: '1:1', note: '' },
]);
sub(['miso','miso paste'], ['soy'], [
  { use: 'Chickpea miso', ratio: '1:1', note: 'Widely available and tastes very close.' },
]);
sub(['soy lecithin','lecithin'], ['soy'], [
  { use: 'Sunflower lecithin', ratio: '1:1', note: 'Identical function, no soy.' },
]);
sub(['hoisin','hoisin sauce','teriyaki','teriyaki sauce','ponzu','tamari'], ['soy'], [
  { use: 'Coconut aminos base', ratio: '1:1, plus a little more salt', note: 'Sweeter and milder — cut any added sugar in the recipe.' },
]);
sub(['soybean oil','vegetable oil'], ['soy'], [
  { use: 'Sunflower, canola or avocado oil', ratio: '1:1', note: '' },
]);

/* --- peanut --- */
sub(['peanut butter'], ['peanut'], [
  { use: 'Sunflower seed butter', ratio: '1:1', note: 'Closest texture. It reacts with baking soda and can turn baked goods green — harmless, but add a teaspoon of lemon juice to stop it.' },
  { use: 'Soy nut butter', ratio: '1:1', note: 'No green reaction. Still soy.' },
]);
sub(['peanut','peanuts','groundnut','groundnuts','beer nuts'], ['peanut'], [
  { use: 'Roasted chickpeas or pumpkin seeds', ratio: '1:1', note: 'For crunch and salt, not for the peanut flavour — nothing replaces that honestly.' },
]);
sub(['peanut oil','arachis oil'], ['peanut'], [
  { use: 'Sunflower or avocado oil', ratio: '1:1', note: 'Both take the same frying heat.' },
]);
sub(['satay','satay sauce','peanut sauce'], ['peanut'], [
  { use: 'Sunflower butter satay', ratio: '1:1', note: 'Same recipe, swap the base. Add a squeeze of lime to lift it.' },
]);

/* --- tree nut --- */
sub(['almond flour','almond meal','nut flour','nut meal'], ['treenut'], [
  { use: 'Sunflower seed flour', ratio: '1:1', note: 'Grind seeds fine yourself or buy it milled. Same green-baking-soda reaction as sunflower butter.' },
  { use: 'Pumpkin seed flour', ratio: '1:1', note: 'Greener colour, no reaction.' },
]);
sub(['almond milk','cashew milk'], ['treenut'], [
  { use: 'Oat or rice milk', ratio: '1:1', note: '' },
]);
sub(['almond butter','cashew butter','nut butter','hazelnut spread'], ['treenut'], [
  { use: 'Sunflower seed butter', ratio: '1:1', note: '' },
]);
sub(['pine nut','pine nuts','pignoli','pesto'], ['treenut'], [
  { use: 'Toasted sunflower or pumpkin seeds', ratio: '1:1', note: 'Toast them dry first or the pesto tastes flat.' },
]);
sub(['walnut','walnuts','pecan','pecans','hazelnut','hazelnuts','pistachio','pistachios','macadamia','brazil nut','nut','nuts','tree nut','tree nuts','chestnut'], ['treenut'], [
  { use: 'Toasted pumpkin or sunflower seeds', ratio: '1:1', note: 'Matches the crunch and the fat. Not the flavour.' },
]);
sub(['almond','almonds'], ['treenut'], [
  { use: 'Toasted sunflower seeds', ratio: '1:1', note: 'For sliced almonds on top, use seeds or crushed GF cornflakes.' },
]);
sub(['marzipan','almond paste','frangipane'], ['treenut'], [
  { use: 'Sunflower seed marzipan', ratio: '1:1', note: 'Sold commercially, or blend sunflower seeds with icing sugar and a little water.' },
]);
sub(['nut oil','walnut oil','almond oil'], ['treenut'], [
  { use: 'Sunflower or avocado oil', ratio: '1:1', note: '' },
]);
sub(['almond extract'], ['treenut'], [
  { use: 'Vanilla extract, or a drop of cherry extract', ratio: '1:1', note: 'Almond extract is often nut-free already — check the bottle before you swap it out.' },
]);

/* --- sesame --- */
sub(['tahini','tahina'], ['sesame'], [
  { use: 'Sunflower seed butter', ratio: '1:1', note: 'Closest texture and bitterness. Pumpkin seed butter also works.' },
]);
sub(['sesame oil','toasted sesame oil'], ['sesame'], [
  { use: 'Toasted sunflower oil, or a little chilli oil', ratio: '1:1', note: 'Nothing matches toasted sesame aroma — expect a different dish, not the same one.' },
]);
sub(['sesame','sesame seed','sesame seeds','gomashio','benne'], ['sesame'], [
  { use: 'Poppy seeds, nigella seeds or hemp hearts', ratio: '1:1', note: '' },
]);
sub(['hummus'], ['sesame'], [
  { use: 'Tahini-free hummus', ratio: '1:1', note: 'Blend chickpeas with sunflower butter, lemon and olive oil.' },
]);
sub(['za’atar','zaatar'], ['sesame'], [
  { use: 'Sumac, thyme and salt', ratio: '1:1', note: 'Za’atar without the sesame, which is most of what it is anyway.' },
]);

/* --- fish / shellfish --- */
sub(['fish sauce','nam pla','nuoc mam'], ['fish'], [
  { use: 'Coconut aminos + extra salt', ratio: '1:1 plus ¼ tsp salt per tbsp', note: 'For more depth, add a teaspoon of miso if soy is allowed.' },
]);
sub(['anchovy','anchovies','anchovy paste','worcestershire','worcestershire sauce'], ['fish'], [
  { use: 'Vegan worcestershire, or capers', ratio: '1:1', note: 'Capers plus a splash of soy give the same salty-savoury hit.' },
]);
sub(['dashi','bonito','bonito flakes','katsuobushi'], ['fish'], [
  { use: 'Shiitake and kombu dashi', ratio: '1:1', note: 'Steep dried shiitake and kombu in cold water overnight.' },
]);
sub(['tuna','salmon','cod','haddock','tilapia','pollock','fish'], ['fish'], [
  { use: 'Chickpea smash, or marinated hearts of palm', ratio: '1:1', note: 'Works in salads and cakes; not a substitute for a cooked fillet.' },
]);
sub(['shrimp','prawn','prawns','shrimps'], ['shellfish'], [
  { use: 'King oyster mushroom, sliced into rounds', ratio: '1:1', note: 'Score them and sear hard — they go springy like shrimp.' },
]);
sub(['crab','crabmeat','crab meat','imitation crab','lobster'], ['shellfish'], [
  { use: 'Shredded hearts of palm', ratio: '1:1', note: 'Imitation crab is usually pollock, so it is a fish problem as often as a shellfish one.' },
]);
sub(['oyster sauce'], ['mollusc'], [
  { use: 'Mushroom stir-fry sauce', ratio: '1:1', note: 'Sold as vegetarian oyster sauce. Check it for wheat.' },
]);
sub(['clam','clams','mussel','mussels','scallop','scallops','squid','calamari'], ['mollusc'], [
  { use: 'King oyster mushroom or artichoke hearts', ratio: '1:1', note: '' },
]);
sub(['shellfish','seafood','seafood stock','fish stock'], ['shellfish','fish'], [
  { use: 'Kombu or mushroom stock', ratio: '1:1', note: 'Kombu is seaweed, not seafood.' },
]);

/* --- the rest --- */
sub(['mustard','dijon','dijon mustard','mustard powder','mustard seed','mustard seeds','honey mustard'], ['mustard'], [
  { use: 'Horseradish, sparingly', ratio: '⅓ of the mustard', note: 'For the bite. In a vinaigrette you also lose the emulsifier — whisk in a little mayo instead.' },
]);
sub(['celery','celeriac','celery salt','celery seed','mirepoix'], ['celery'], [
  { use: 'Fennel stalk or leek', ratio: '1:1', note: 'Fennel is closer raw, leek closer cooked.' },
]);
sub(['wine','red wine','white wine'], ['sulphite','alcohol'], [
  { use: 'Stock + a splash of vinegar', ratio: '1:1 stock, 1 tsp vinegar per cup', note: '' },
]);
sub(['dried apricot','dried apricots','dried fruit','raisins'], ['sulphite'], [
  { use: 'Unsulphured dried fruit', ratio: '1:1', note: 'Labelled "no sulphur added". Darker in colour, same fruit.' },
]);
sub(['lupin','lupine','lupin flour'], ['lupin'], [
  { use: 'Chickpea flour', ratio: '1:1', note: '' },
]);
sub(['cornstarch','corn starch','corn flour'], ['corn'], [
  { use: 'Arrowroot or tapioca starch', ratio: '1:1', note: 'Arrowroot thins again under long heat — add it at the end.' },
]);
sub(['corn syrup','high fructose corn syrup'], ['corn'], [
  { use: 'Golden syrup or brown rice syrup', ratio: '1:1', note: '' },
]);
sub(['gelatin','gelatine'], ['pork','fish'], [
  { use: 'Agar agar', ratio: '1 tsp powder per 1 tbsp gelatin', note: 'Sets firmer and at room temperature. Must be boiled to activate.' },
]);
sub(['bacon','pancetta','ham','prosciutto','lard','chorizo','pork'], ['pork'], [
  { use: 'Smoked turkey, beef bacon, or mushrooms for a meat-free version', ratio: '1:1', note: 'For lard, use refined coconut oil or beef tallow.' },
]);

/* generic fallback, so no flagged ingredient is left without an answer */
const GENERIC = {
  milk: [{ use: 'A plant-based equivalent', ratio: '1:1', note: 'Soy for protein and browning, oat for baking, coconut for richness.' }],
  egg: [{ use: 'Flax egg or commercial egg replacer', ratio: '1 tbsp flax + 3 tbsp water per egg', note: '' }],
  wheat: [{ use: 'A certified gluten-free equivalent', ratio: '1:1', note: 'Add xanthan or psyllium where the gluten was doing structural work.' }],
  gluten: [{ use: 'A certified gluten-free equivalent', ratio: '1:1', note: '' }],
  soy: [{ use: 'A pea, chickpea or coconut-based equivalent', ratio: '1:1', note: '' }],
  peanut: [{ use: 'Sunflower seed equivalent', ratio: '1:1', note: '' }],
  treenut: [{ use: 'Sunflower or pumpkin seed equivalent', ratio: '1:1', note: '' }],
  sesame: [{ use: 'Sunflower seed equivalent', ratio: '1:1', note: '' }],
  fish: [{ use: 'A mushroom, kombu or hearts-of-palm equivalent', ratio: '1:1', note: '' }],
  shellfish: [{ use: 'King oyster mushroom or hearts of palm', ratio: '1:1', note: '' }],
  mollusc: [{ use: 'King oyster mushroom or artichoke hearts', ratio: '1:1', note: '' }],
  mustard: [{ use: 'Horseradish, sparingly', ratio: '⅓ of the mustard', note: '' }],
  celery: [{ use: 'Fennel stalk or leek', ratio: '1:1', note: '' }],
  sulphite: [{ use: 'An unsulphured version of the same ingredient', ratio: '1:1', note: '' }],
  lupin: [{ use: 'Chickpea flour', ratio: '1:1', note: '' }],
  corn: [{ use: 'Arrowroot, tapioca or cane-based equivalent', ratio: '1:1', note: '' }],
  pork: [{ use: 'Beef, turkey or a mushroom-based equivalent', ratio: '1:1', note: '' }],
  alcohol: [{ use: 'Stock, juice or a non-alcoholic version', ratio: '1:1', note: '' }],
  nightshade: [{ use: 'Beetroot, carrot or squash depending on the role', ratio: '1:1', note: '' }],
  allium: [{ use: 'Asafoetida, a pinch, or fennel', ratio: '⅛ tsp asafoetida per onion', note: '' }],
};

/* things a swap genuinely cannot fix */
const NO_SUB = {
  seitan: 'Seitan is wheat gluten. There is no gluten-free seitan — the dish needs a different protein.',
  'vital wheat gluten': 'This is pure gluten. Remove it and rebuild the recipe around a binder like psyllium.',
  casein: 'A processing additive inside a finished product. You cannot swap it at home — the manufacturer has to reformulate.',
  caseinate: 'A processing additive inside a finished product. You cannot swap it at home — the manufacturer has to reformulate.',
  'sodium caseinate': 'A processing additive inside a finished product. You cannot swap it at home.',
  'natural flavor': 'You cannot substitute what is not named. Ask the supplier what is in it.',
  'natural flavors': 'You cannot substitute what is not named. Ask the supplier what is in it.',
  'modified food starch': 'The source grain is undeclared. Ask the supplier, or use a product that names its starch.',
  spices: 'An undeclared blend. Buy single spices and blend them yourself if this matters.',
  seasoning: 'An undeclared blend. Buy single spices and blend them yourself if this matters.',
};

/**
 * Build a substitution plan for the allergens in `scope` (a Set of keys).
 */
function substitute(result, scope) {
  const rows = [], blocked = [], seen = new Set();
  const covered = {};   // allergen -> every ingredient hit for it has an answer
  const perLine = new Map();

  // real prep steps count (an egg wash is an ingredient); facility lines do not
  const walk = [...result.ingredients, ...result.prep.filter(l => !l.facility)];
  for (const ln of walk) {
    for (const h of ln.hits) {
      if (!scope.has(h.a)) continue;
      if (LEVELS[h.l] < 2) continue;              // possible-level is a question, not a swap
      // "Butter (cream, salt)" — swapping the butter already handles the cream
      if (!perLine.has(ln.text)) perLine.set(ln.text, new Set());
      const done = perLine.get(ln.text);
      if (done.has(h.a)) continue;
      done.add(h.a);
      const key = h.term.toLowerCase();
      (covered[h.a] = covered[h.a] || { total: 0, done: 0 }).total++;

      const stop = NO_SUB[key];
      if (stop) {
        if (!seen.has('x' + key)) { seen.add('x' + key); blocked.push({ term: h.term, why: stop }); }
        continue;
      }
      const entry = SUBS[key];
      const swaps = entry ? entry.swaps : GENERIC[h.a];
      if (!swaps) continue;
      covered[h.a].done++;
      if (seen.has(key)) continue;
      seen.add(key);
      rows.push({
        term: h.term, line: ln.text, allergens: [h.a],
        swaps, caveat: entry ? entry.caveat : '',
      });
    }
  }
  // merge allergens where one swap answers several (coconut aminos clears soy and wheat)
  for (const r of rows) {
    const e = SUBS[r.term.toLowerCase()];
    if (e) r.allergens = e.fixes.filter(a => scope.has(a));
    if (!r.allergens.length) r.allergens = [result.found[Object.keys(result.found)[0]]?.a].filter(Boolean);
  }

  const cleared = [...scope].filter(a => covered[a] && covered[a].done === covered[a].total && covered[a].total > 0);
  const stillThere = [...scope].filter(a => result.found[a] && !cleared.includes(a));

  // what swapping will never fix
  const unfixable = [];
  for (const c of result.cross) {
    if (!c.allergens.some(a => scope.has(a))) continue;
    unfixable.push({ label: c.trigger, why: c.note, kind: 'cross-contact' });
  }
  for (const v of result.vague) unfixable.push({ label: v.t, why: v.why, kind: 'undeclared' });

  return { rows, blocked, cleared, stillThere, unfixable };
}

export { analyze, substitute, ALLERGENS, LEVELS, scanLine };
