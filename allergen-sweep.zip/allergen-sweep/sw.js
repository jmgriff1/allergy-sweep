/**
 * Cache the app shell so the scanner works with no signal — standing in a shop
 * aisle on one bar is the normal case, not the edge case.
 *
 * Text scanning is fully offline: the rulebook ships with the page. Only photo
 * reading needs the network, and /api/ is never cached.
 */
const CACHE = 'sweep-v1';
const SHELL = ['/', '/index.html', '/styles.css', '/app.js', '/engine.js', '/icon.svg', '/manifest.webmanifest'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.pathname.startsWith('/api/')) return;
  if (url.origin !== self.location.origin) return;

  // Network first so a deploy reaches people immediately; cache is the fallback.
  e.respondWith(
    fetch(e.request)
      .then(res => {
        const copy = res.clone();
        caches.open(CACHE).then(c => c.put(e.request, copy)).catch(() => {});
        return res;
      })
      .catch(() => caches.match(e.request).then(hit => hit || caches.match('/index.html')))
  );
});
