import { analyze, substitute } from '../engine.js';

let pass = 0, fail = 0;
function check(label, ingredients, expect) {
  const r = analyze({ ingredients });
  const got = Object.keys(r.found).sort();
  const errs = [];
  for (const a of (expect.has || [])) if (!got.includes(a)) errs.push('MISSING ' + a);
  for (const a of (expect.not || [])) if (got.includes(a)) errs.push('FALSE POSITIVE ' + a + ' (' + (r.found[a].evidence.map(e=>e.term).join(',')) + ')');
  for (const [a, lv] of Object.entries(expect.level || {})) {
    if (!r.found[a]) errs.push('MISSING ' + a);
    else if (r.found[a].level !== lv) errs.push(a + ' level=' + r.found[a].level + ' want ' + lv);
  }
  if (errs.length) { fail++; console.log('FAIL  ' + label + '\n      ' + errs.join('\n      ') + '\n      got: ' + got.join(', ')); }
  else { pass++; console.log('ok    ' + label + '  [' + got.join(', ') + ']'); }
}

check('almond milk is not dairy', ['2 cups almond milk'], { has: ['treenut'], not: ['milk'] });
check('oat milk is not dairy', ['1 cup oat milk'], { not: ['milk'] });
check('coconut milk is not dairy or wheat', ['400ml coconut milk'], { not: ['milk','wheat'] });
check('peanut butter is not dairy', ['3 tbsp peanut butter'], { has: ['peanut'], not: ['milk'] });
check('cocoa butter is not dairy', ['50g cocoa butter'], { not: ['milk'] });
check('cream of tartar is not dairy', ['1 tsp cream of tartar'], { not: ['milk'] });
check('buttermilk is dairy', ['1 cup buttermilk'], { level: { milk: 'contains' } });
check('casein is hidden dairy', ['sodium caseinate'], { level: { milk: 'hidden' } });
check('whey is hidden dairy', ['whey protein concentrate'], { level: { milk: 'hidden' } });
check('eggplant is not egg', ['1 large eggplant, cubed'], { not: ['egg'], has: ['nightshade'] });
check('egg noodles are egg + wheat', ['8 oz egg noodles'], { has: ['egg','wheat','gluten'] });
check('buckwheat is not wheat', ['1 cup buckwheat flour'], { not: ['wheat','gluten'] });
check('almond flour is not wheat', ['2 cups almond flour'], { has: ['treenut'], not: ['wheat'] });
check('rice flour is not wheat', ['1 cup rice flour'], { not: ['wheat','gluten'] });
check('semolina is wheat', ['200g semolina'], { level: { wheat: 'contains', gluten: 'contains' } });
check('soy sauce is soy + wheat risk', ['2 tbsp soy sauce'], { has: ['soy','wheat','gluten'] });
check('worcestershire is fish', ['1 tsp worcestershire sauce'], { has: ['fish'] });
check('nutmeg is not a tree nut', ['1/4 tsp nutmeg'], { not: ['treenut'] });
check('water chestnut is not a tree nut', ['1 can water chestnuts'], { not: ['treenut'] });
check('butternut squash is clean', ['1 butternut squash, diced'], { not: ['treenut','milk'] });
check('tahini is sesame', ['1/3 cup tahini'], { level: { sesame: 'contains' } });
check('hummus is sesame', ['200g hummus'], { has: ['sesame'] });
check('imitation crab is shellfish-adjacent', ['imitation crab sticks'], { has: ['shellfish'] });
check('oyster sauce is mollusc', ['1 tbsp oyster sauce'], { has: ['mollusc'] });
check('barley is gluten not wheat', ['1/2 cup pearl barley'], { has: ['gluten'], not: ['wheat'] });
check('malt vinegar is gluten', ['malt vinegar'], { has: ['gluten'] });
check('oats are gluten cross-risk only', ['1 cup rolled oats'], { level: { gluten: 'possible' } });
check('lecithin is hidden soy', ['soy lecithin'], { level: { soy: 'contains' } });
check('pesto is tree nut', ['3 tbsp pesto'], { has: ['treenut'] });
check('marzipan is tree nut', ['100g marzipan'], { has: ['treenut'] });
check('miso is soy', ['2 tbsp white miso'], { has: ['soy'] });
check('mirepoix is celery', ['1 cup mirepoix'], { has: ['celery'] });
check('dijon is mustard', ['1 tsp dijon mustard'], { has: ['mustard'] });
check('nut-free claim does not flag nuts', ['nut-free chocolate chips'], { not: ['treenut','peanut'] });
check('dairy-free does not flag milk', ['dairy-free spread'], { not: ['milk'] });
check('gluten-free flour blend', ['gluten-free flour blend'], { not: ['wheat'] });

console.log('\n--- conflict + cross-contact ---');
const r1 = analyze({
  title: 'Vegan Brownie',
  ingredients: ['almond milk','dairy-free chocolate chips','whey protein isolate','all-purpose flour'],
  claims: ['vegan','dairy-free'],
});
console.log('claims:', r1.claims);
console.log('conflicts:', JSON.stringify(r1.conflicts));
console.log('cross:', r1.cross.map(c => c.trigger));

const r2 = analyze({
  title: 'Fish & Chips',
  ingredients: ['cod fillet','all-purpose flour','beer','potatoes','vegetable oil','natural flavors'],
  prep: ['Deep fry at 180C in the shared fryer'],
});
console.log('\nfish&chips found:', Object.entries(r2.found).map(([k,v])=>k+':'+v.level).join(', '));
console.log('cross:', r2.cross.length, r2.cross.map(c=>c.trigger));
console.log('vague:', r2.vague.map(v=>v.t));

console.log('\n' + pass + ' passed, ' + fail + ' failed');

// --- substitution plan ---
console.log('\n--- substitutions ---');
const sr = analyze({
  title: 'Almond croissant',
  ingredients: ['Enriched wheat flour', 'Butter (cream, salt)', 'Almond paste (almonds, sugar)', 'Whey powder'],
  prep: ['Egg wash applied before bake.', 'Baked in a case shared with hazelnut danish.'],
});
const plan = substitute(sr, new Set(['milk', 'treenut', 'wheat', 'gluten', 'egg']));
console.log('cleared:', plan.cleared.join(', '));
plan.rows.forEach(r => console.log('  ' + r.term + ' -> ' + r.swaps[0].use));
if (plan.cleared.length !== 5) { console.log('FAIL: expected all five cleared'); process.exit(1); }
console.log('\nAll good.');
